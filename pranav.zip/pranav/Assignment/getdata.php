<?php

include_once("dbconn.php");
header('Content Type:application/json');
$method = $_SERVER['REQUEST_METHOD'];
$data = array(); 
$roll = filter_var(trim($_GET['roll']),FILTER_SANITIZE_NUMBER_INT);
$chart = filter_var(trim($_GET['bar']),FILTER_SANITIZE_STRING);
$col = filter_var(trim($_GET['col']),FILTER_SANITIZE_STRING);
if($method == "GET" && $method != "" && $roll !="" )
{
	$sql = "SELECT * FROM dashboard_data where roll_no=$roll";
	$result = mysql_query($sql,$con);
	if($result)
	{
		$row = mysql_fetch_assoc($result);
		$data['info'] = $row;
		if($chart != "getchart")
		{
			echo json_encode($data);
		}
	}
	else
	{
		$data['error'] = mysql_error(); 
		echo json_encode($data);
	}
}
if($col)
{	
	$data = array();	
		$sql = "SELECT  $col FROM dashboard_data";
		$result = mysql_query($sql,$con);
		if($result)
		{
			while($row = mysql_fetch_assoc($result))
			{
				array_push($data,$row);	
			}
			
		}	

	echo json_encode($data);
}
if($chart == "getchart" && $chart != " ")
{
	$sql = "SELECT AVG(m1),AVG(m2),AVG(m3)FROM dashboard_data";
	$result = mysql_query($sql,$con);
	 if($result)
        {
		$row = mysql_fetch_array($result);
		$data['chart'] = $row;
		echo json_encode($data);  
        }

}
mysql_close($con);
?>
