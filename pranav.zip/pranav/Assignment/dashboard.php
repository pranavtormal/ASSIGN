<!DOCTYPE html>
<html>
<head>
	<meta content="text/html" charset="UTF-8"/>
	<title>Student Dashboard</title>
	<style>
		.outerDiv{
			height:690px;
			width:1300px;
			border:1px solid grey;
			margin:0 auto;
			background:#CCCCFF;
			overflow:auto;
		}
		.studentInfoTable{
			height:50px;
			width:100%;
			margin:auto;
			
		}
		 .studentInfoTable th{
			background:#3399FF;
			height:40px;
		}
		 .studentInfoTable td{
                        text-align:center;
			font-weight:bold;
                }
		.innerDiv{
                        height:650px;
                        width:1250px; 
                        margin:0 auto;
			margin-top:30px;
                       
                }
		.studentRollDiv{
			height:50px;
                        width:600px;
			float:right;
		}
		.avgGradeDiv{
			margin-top:20px;
			height:428px;
			border-radius:10px;
		}
		.avgGradeLeftDiv{
			border:1px solid blue;
                        height:428px;
			width:615px;
			float:left;
                        background:white;
                        border-radius:10px;
		}
		.avgGradeRightDiv{
                        border:1px solid blue;
                        height:428px;
                        width:615px;
			float:right;
                        background:white;
                        border-radius:10px;
                }
		.mPieDiv{
			border:1px solid blue;
                        height:250px;
                        width:407px;
                        background:white;
                        border-radius:8px;
		}
		.dragOptionDiv{
			width:615px;	
		}
		#Ulist li{
			display:inline;
			font-size:20px;
			font-weight:bold;
			margin-left:30px;
			cursor:pointer;
		}
		
	</style>
	<script src="jquery-1.7.1.min.js"></script>
	<script src="Chart.js"></script>
	<script src="highcharts.js"></script>
	<script>
		$(document).ready(function(){
			var roll =$('#rollNo').val();
			var a = "function call";
			if(roll !=null && roll != " " && roll != "undefined" )
                        {
                                $.ajax({
                                        type:'GET',
                                        url:'getdata.php',
                                        contentType:'application/json',
                                        dataType:'json',
                                        data:{"roll":roll,"bar":"getchart"},
                                        success:function(response,a,b){			
				
						var score = []; //array for avg of per subject
						var score1 = [];
						var subject = ["m1","m2","m3"];
						
						for(var j  in response.chart)
						{
							score.push(response.chart[j]);
						}
						
						var len = score.length;
						score.splice((len/2)-1,len/2); //remove last duplicate values
						var ctx = $('#barChart');
						function getChart(subject,score,ctx) // function to for bar Chart
						{
							var chartdata = {
									labels:subject,
									datasets:[
										{
										label:'AVG Grade',
										backgroundColor:'green',
										borderColor:'rgba(200,200,200,0.75)',
										hoverBackgroundColor:'#9999FF',
										data:score				
										}
										]
									};
		 					var graph = new Chart(ctx,{type:'bar',data:chartdata,
								options: {
            								scales: {
                								yAxes: [{
                    									ticks: {
                        									beginAtZero:true,
                        									min: 0,
                        									max: 100   
                    										}
                  									}]
               									}
            							}});
						} //function end here
						getChart(subject,score,ctx); //for left bar chart
			
                                                for(var i in response) // display table coloumn data
                                                {
                                                        $('#r2').remove();
							score1.push(response.info.m1);//score1-array to store reocrd
                                                        score1.push(response.info.m2);
                                                        score1.push(response.info.m3);
                                                        score1.push(response.info.grade);
                                                        $('#studentInfoTable').append('<tr id="r2"><td>'+response.info.name+'</td><td>'+response.info.class+'</td><td>'+response.info.m1+'</td><td>'+response.info.m2+'</td><td>'+response.info.m3+'</td><td>'+response.info.grade+'</td></tr>');
                                                }
						var len = score1.length;
                                                score1.splice((len/2)-1,len/2);  //remove repeated records
						var subject = ['m1','m2','m3','Grade'];
						var ctx1 = $('#rightBarChart');
						getChart(subject,score1,ctx1);  //right side bar Chart
						var m11 = [];
						var m22 = [];
						var m33 = [];
						m11.push(response.info.m1);
						var remainder = 100 - (response.info.m1) ;
						m11.push(remainder);
						m22.push(response.info.m2);
						m22.push(100-(response.info.m2));
						m33.push(response.info.m3);
						m33.push(100-(response.info.m3));
						//console.log(m33);
						function pieChart(label,m,clr)
						{
							var chartdata = {
                                                                	labels:label,
                                                                	datasets:[
                                                                        	{
                                                                        		backgroundColor:clr,
                                                                       			data:m
                                                                        	}
                                                                        	]
                                                        }; 
							return chartdata;
					
						}
                                                var ctxPie = $('#m1pieChart');
						var label = ['m1'];
						var clr = ['green','grey'];
                                                var graph1 = new Chart(ctxPie,{type:'pie',data:pieChart(label,m11,clr)});
						var ctxPie = $('#m2pieChart');
						var label = ['m2'];
						var clr = ['red','grey'];
                                                var graph1 = new Chart(ctxPie,{type:'pie',data:pieChart(label,m22,clr)});// m2 Pie Chart
                                                var ctxPie = $('#m3pieChart');
						var label = ['m3'];
						var clr = ['blue','grey'];
                                                var graph1 = new Chart(ctxPie,{type:'pie',data:pieChart(label,m33,clr)});// m3 Pie Chart
                                        }
                                });
                        }	
		});
		
		function getColumn()
		{
			var col = document.getElementById('drop').value;
			document.getElementById("alertSpan").innerHTML = "";
			var rollNo = $('#rollNo').val();
			var col = col.trim();
			if(col)
			{
				var str = col.replace(/,\s*$/,"");
				//console.log(str);
				$.ajax({
					type:'GET',
					url:'getdata.php',
					contentType:'application/json',
					dataType:'json',
					data:{"col":str},
					success:function(resp){
						console.log(resp);
						var key;
						var obj;
						var m1 = [];
						var m2 = [];
						var m3 = [];
						var grade = [];
						for(var i in resp)
						{	
							var obj1 = resp[i];
							key = Object.keys(resp[i]);
							obj = resp[i];
							
							if("m1" in obj1)
							{	
								m1.push(parseInt(obj1.m1));
							}
							 if("m2" in obj1)
							{
								m2.push(parseInt(obj1.m2));
							}
							 if("m3" in obj1)
							{
								m3.push(parseInt(obj1.m3));
							}
							if("grade" in obj1)
							{
								grade.push(parseFloat(obj1.grade));
							}
						}
						function highChartBar(data)
						{
						
							$('#avgGradeLeftDiv').highcharts({
								chart:{
									type:'column'
								},
								title:{
									text:'Maths marks Bar Chart'
								},
								xAxis:{
									categories:["RollNo-1","RollNo-2","RollNo-3","RollNo-4","RollNo-5"]
								},
								yAxis:{
									min:0,
									max:100
								},
								legend:{
									reversed:true
								},
								series:data
							});
						}
						if( m1.length > 0 && m1 != null && m2.length == 0 && m3.length == 0 && grade.length == 0)
						{
							
							var data = [{name:'M1',data:m1}];
							highChartBar(data);

						}
						else if(m2.length > 0 && m2 != null && m1.length == 0 && m3.length == 0 && grade.length == 0)
						{
							var data = [{name:'M2',data:m2}];
                                                        highChartBar(data);
						}
						else if(m3.length > 0 && m3 != null && m1.length == 0 && m2.length == 0 && grade.length == 0)
						{
							var data = [{name:'M3',data:m3}];
                                                        highChartBar(data);
						}
						else if(grade.length > 0 && grade != null && m1.length == 0 && m2.length == 0 && m3.length == 0)
						{
							var data = [{name:'Grade',data:grade}];
                                                        highChartBar(data);
						}
						else if(m1.length > 0 && m2.length > 0 && m3.length == 0 && grade.length == 0)
						{
							var data = [{name:'M1',data:m1},{name:'M2',data:m2}];
                                                        highChartBar(data);
						}
						else if(m1.length > 0 && m3.length > 0 && m2.length == 0 && grade.length == 0)
						{
							var data = [{name:'M1',data:m1},{name:'M3',data:m3}];
                                                        highChartBar(data);
						}
						else if(m1.length > 0 && grade.length > 0 && m2.length == 0 && m3.length == 0)
                                                {
                                                        var data = [{name:'M1',data:m1},{name:'Grade',data:grade}];
                                                        highChartBar(data);
                                                }
						else if(m2.length > 0 && m3.length > 0 && m1.length == 0 && grade.length == 0)
                                                {
                                                        var data = [{name:'M2',data:m2},{name:'M3',data:m3}];
                                                        highChartBar(data);
                                                }
						else if(m2.length > 0 && grade.length > 0 && m1.length == 0 && m3.length == 0)
                                                {
                                                        var data = [{name:'M2',data:m2},{name:'Grade',data:grade}];
                                                        highChartBar(data);
                                                }
						else if(m3.length > 0 && grade.length > 0 && m2.length == 0 && m1.length == 0)
                                                {
                                                        var data = [{name:'M3',data:m3},{name:'Grade',data:grade}];
                                                        highChartBar(data);
                                                }
						else if(m1.length > 0 && m2.length > 0 && m3.length > 0 && grade.length == 0)
                                                {
                                                        var data = [{name:'M1',data:m1},{name:'M2',data:m2},{name:'M3',data:m3}];
                                                        highChartBar(data);
                                                }
						else if(m1.length > 0 && m2.length > 0 && grade.length > 0 && m3.length == 0)
                                                {
                                                        var data = [{name:'M1',data:m1},{name:'M2',data:m2},{name:'Grade',data:grade}];
                                                        highChartBar(data);
                                                }
						else if(m1.length > 0 && grade.length > 0 && m3.length > 0 && m2.length == 0)
                                                {
                                                        var data = [{name:'M1',data:m1},{name:'M3',data:m3},{name:'Grade',data:grade}];
                                                        highChartBar(data);
                                                }
						else if(m2.length > 0 && grade.length > 0 && m3.length > 0 && m1.length == 0)
                                                {
                                                        var data = [{name:'M2',data:m2},{name:'M3',data:m3},{name:'Grade',data:grade}];
                                                        highChartBar(data);
                                                }
						else
						{
							var data = [{name:'M1',data:m1},{name:'M2',data:m2},{name:'M3',data:m3},{name:"Grade",data:grade}];
                                                        highChartBar(data);
						}

					}
				});
				
			}
			else
			{
				document.getElementById("alertSpan").innerHTML = "Drag and Drop Column";
			}	
			
		}//getColumn function end here

		function allowDrop(ev) 
		{
			 ev.preventDefault(); 
		}

		function drag(ev)
		{
    			ev.dataTransfer.setData("text", ev.target.id);
		}

		function drop(ev) 
		{
    			ev.preventDefault();
    			var data = ev.dataTransfer.getData("text"); //get id of element
			//console.log(data);
			document.getElementById("drop").value += data + ','; //get value in textbox	
    			//ev.target.appendChild(document.getElementById(data));//append element into target
			document.getElementById(data).remove(); //remove element if only value required
			
		}


		function getData()
		{
			var r = $('#rollNo').val();
			if(r)
			{
				$.ajax({
					type:'GET',
					url:'getdata.php',
					contentType:'application/json',
					dataType:'json',
					data:{"roll":r},
					success:function(response){
						console.log(response);
						var score = [];
						var subject =['m1','m2','m3','Grade'];	
						for(var i in response)
						{
							score.push(response[i].m1);
							score.push(response[i].m2);
							score.push(response[i].m3);
							score.push(response[i].grade);
							$('#r2').remove(); //remove previous record
							$('#studentInfoTable').append('<tr id="r2"><td>'+response[i].name+'</td><td>'+response[i].class+'</td><td>'+response[i].m1+'</td><td>'+response[i].m2+'</td><td>'+response[i].m3+'</td><td>'+response[i].grade+'</td></tr>');
						}
						var subject = ['m1','m2','m3','Grade'];
                                                $('#rightBarChart').remove(); // remove previous canvas
						$('#avgGradeRightDiv').append('<canvas id= "rightBarChart" style="height:100%;width:100%"></canvas>');
						$('.chartjs-hidden-iframe').remove();	
						var ctx1 = $('#rightBarChart'); //rightside bar Chart
						var chartdata = {
                                                                labels:subject,
                                                                datasets:[
                                                                        {
                                                                        label:'AVG Grade',
                                                                        backgroundColor:'green',
                                                                        borderColor:'rgba(200,200,200,0.75)',
                                                                        hoverBackgroundColor:'#9999FF',
                                                                        hoverBorderColor:'rgba(200,200,200,0.75)',
                                                                        data:score
                                                                        }
                                                                        ]
                                                                };
             				 	
                                                var graph = new Chart(ctx1,{type:'bar',data:chartdata,
                                                        options: {
                                                                scales: {
                                                                        yAxes: [{
                                                                                ticks: {
                                                                                        beginAtZero:true,
                                                                                        min: 0,
                                                                                        max: 100
                                                                                        }
                                                                                }]
                                                                        }
                                                
								 }
						});
						$('.chartjs-hidden-iframe').remove(); // remove iframe
						var m1 = [];
						var m2 = [];
						var m3 = [];
						m1.push(response.info.m1);
						m1.push(100 - (response.info.m1));
						m2.push(response.info.m2);
						m2.push(100 - (response.info.m2));
						m3.push(response.info.m3);
						m3.push(100 - (response.info.m3));
						 function pieChart(label,m,color) //function for piedata
                                                {
                                                        var piedata = {
                                                                labels:label,
                                                                datasets:[
                                                                        {
                                                                                backgroundColor:color,
                                                                                data:m
                                                                        }
                                                                        ]
                                                        };
                                                        return piedata;
                                                }
						$('#m1pieChart').remove(); //remove previous m1canvas 
						$('#m1PieDiv').append('<canvas id="m1pieChart" name="m1pieChart" style="height:100%;width:100%;">');
						var piectx = $('#m1pieChart');
						var label = ['m1'];
						var color = ['green','grey'];
						var piegraph1= new Chart(piectx,{type:'pie',data:pieChart(label,m1,color)});//for m1 pi Chart
						 $('#m2pieChart').remove(); //remove previous m2canvas
                                                $('#m2PieDiv').append('<canvas id="m2pieChart" name="m2pieChart" style="height:100%;width:100%;">');
                                                var piectx = $('#m2pieChart');
                                                var label = ['m2'];
						var color = ['red','grey'];
                                                var piegraph2= new Chart(piectx,{type:'pie',data:pieChart(label,m2,color)});
						 $('#m3pieChart').remove(); //remove previous m3canvas
                                                $('#m3PieDiv').append('<canvas id="m3pieChart" name="m3pieChart" style="height:100%;width:100%;">');
                                                var piectx = $('#m3pieChart');
                                                var label = ['m3'];
						var color = ['blue','grey'];
                                                var piegraph3= new Chart(piectx,{type:'pie',data:pieChart(label,m3,color)});
					}
				});
			}
		}
	</script>
</head>

<body bgcolor="grey">
	<div id="outerDiv" name="outerDiv" class="outerDiv">
		<div id="innerDiv" name="innerDiv" class="innerDiv">
			<div id="studentRollDiv" name="studentRollDiv" class="studentRollDiv">
				<table style="float:right">
					<tr>
						<th><font size="5">Student Roll No:</font></th>
						<th><input type="number" id="rollNo" value="1" min="1" max="5" onclick="getData()" style="height:24px; border-radius:5px;text-align:center;"/></th>
					</tr>
				</table>
			</div>
			<div id="studentInfoDiv" name="studentInfoDiv" style="height:200px;border:1px solid grey;" >
			<table border="1" id="studentInfoTable" name="studentInfoTable" class="studentInfoTable">
				<tr>
					<th width="300px">Name</th>
					<th>Class</th>
					<th>M1</th>
					<th>M2</th>
					<th>M3</th>
					<th>Grade</th>
				</tr>
			</table>
			<div id="dragDiv">
				<div name="leftUl" class="dragOptionDiv" style="float:left">
					<ul id="Ulist">
						<li draggable="true" ondragstart="drag(event)" id="m1">M1</li>
						<li draggable="true" ondragstart="drag(event)" id="m2">M2</li>
						<li draggable="true" ondragstart="drag(event)" id="m3">M3</li>
						<li draggable="true" ondragstart="drag(event)" id="grade">Grade</li>
					</ul>
				</div>
				<div id="dropDiv" name="rightTextDiv" class="dragOptionDiv" style="float:right">
					<div id="Droptext" ondrop="drop(event)" ondragover="allowDrop(event)" style="margin-top:15px;height:30px;">
					<input type="text" id="drop" style="height:25px;width:250px" readonly/>
					<span id="alertSpan" style="color:red"></span>
					<button id="btnOk" style="height:30px" onclick="getColumn()"> Generate</button>
</div>
				</div>
			</div>
			</div> <!--end of studentInfoDiv-->
			<div id="avgGradeDiv" name="avgGradeDiv" class="avgGradeDiv">
				<div id="avgGradeLeftDiv" name="avgGradeLeftDiv" class="avgGradeLeftDiv">
					<canvas id= "barChart" style="height:100%;width:100%"></canvas>
				</div>
				<div id="avgGradeRightDiv" name="avgGradeRightDiv" class="avgGradeRightDiv">
					<canvas id= "rightBarChart" style="height:100%;width:100%"></canvas>
                                </div>
			</div>
			<div id="pieChartDiv" name="pieChartDiv" style="margin-top:10px" class="pieChartDiv">
				<div id="m1PieDiv" name="m1PieDiv" style="float:left" class="mPieDiv">
                                        <canvas id= "m1pieChart" style="height:100%;width:100%"></canvas>
                                </div>
				 <div id="m2PieDiv" name="m2PieDiv" style="float:left;margin-left:10px" class="mPieDiv">
                                        <canvas id= "m2pieChart" style="height:100%;width:100%"></canvas>
                                </div>
				 <div id="m3PieDiv" name="m3PieDiv" style="float:right" class="mPieDiv">
                                        <canvas id= "m3pieChart" style="height:100%;width:100%"></canvas>
                                </div>
			</div> <!--end of piechatDiv-->
		</div> <!--end of innerDiv-->
	</div>  <!--end of outrDiv-->
</body>
</html>
