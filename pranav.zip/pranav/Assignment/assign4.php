<?php

function ini_read()
{
        $file=fopen("abc_w.ini","r");
        $arr=array();
        if($file)
        {
                while(!feof($file))
                {
                        $data=trim(fgets($file));
                        if(strpos($data,"[")=== 0)
                        {
                                $section=trim($data,"[");
                                $sec=trim(str_replace("]",'',$section));
                                $arr[$sec]=array();
                        }
                        else
                        {       if($data !="")
                                {
                                $raw=explode("=",$data);
                                $key=trim($raw[0]);
                                $value=trim($raw[1]);
                                $val=trim(str_replace('"','',$value));
                                $arr[$sec][$key]=trim($val);
                                }
                        }
                }
        fclose($file);
        return $arr;
        }
	{
                echo "File not Found.";
        }
}
$a=ini_read();
//print_r($a);

if($_POST['save'])
{
        //$arr[]=array();
        $arr[WIN][FILEAV] = $_POST['fileav']?"1":"0";
        $arr[WIN][WEBPRO] = $_POST['webpro']?"1":"0";
        $arr[WIN][FIREWALL] = $_POST['firewall']?"1":"0";
        $arr[WIN][ODSSCHEDULE] = $_POST['ods_schedule']?"1":"0";
        $arr[WIN][MWLI] = $_POST['mwli']?"1":"0";
        $arr[WIN][MWLE] = $_POST['mwle']?"1":"0";
        $arr[LINUX][LINUXFILEAV]  = $_POST['lfile_av']?"1":"0";
        $arr[LINUX][LINUXODS] = $_POST['linuxods']?"1":"0";
        $arr[LINUX][LINUXSCHEDULE] = $_POST['lschedule']?"1":"0";
        $arr[LINUX][LINUXSCHEDULEUPDATE] = $_POST['lschedule_update']?"1":"0";

        function ini_write($arr)
        {
                if($arr)
                {
                        $file=fopen("abc_w.ini","w+");
                        $delim = '"';
                        if($file)
                        {
                                $sec_arr=array_keys($arr);
                                foreach($sec_arr as $sec)
                                {
                                        $sec_arr_keys = array_keys($arr[$sec]);
					 fwrite($file,"[$sec]\n");
                                        foreach($sec_arr_keys as $val)
                                        {
                                                $data = $arr[$sec][$val];
                                                fwrite($file,"$val=$delim$data$delim\n");

                                        }
                        }
                        fclose($file);
                        }
                        else
                        {
                                echo "Error in writing File";
                        }
                }
        }
        ini_write($arr);
}
?>
<html>
<head>
        <title>Policy</title>
        <style>

        </style>
</head>
<body><center>
<table width="100%" id="outer" border="" height="300px">
        <tr>
        <td><form method="post">
                <fieldset>
                        <legend>WIN</legend>
                <table style="white-space:nowrap;">
                        <tr>

                                <td width="200px">
                                <input type="checkbox" name="fileav"
                                <?php
				 if($a["WIN"]["FILEAV"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> FILEAV
                                </td>
                                <td>
                                <input type="checkbox" name="webpro"
                                <?php
                                        if($a["WIN"]["WEBPRO"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                />WEBPROTECTION
                                </td>
                        </tr>
                        <tr>
                                <td width="200px">
                                <input type="checkbox" name="firewall";
                                <?php
                                        if($a["WIN"]["FIREWALL"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> FIREWALL
                                </td>
                                <td>
                                <input type="checkbox" name="ods_schedule"
                                <?php
                                        if($a["WIN"]["ODSSCHEDULE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> ODSSCHEDULE
				 </td>
                        </tr>
                        <tr>
                                <td width="200px">
                                <input type="checkbox" name="mwli"
                                <?php
                                        if($a["WIN"]["MWLI"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> MWLI
                                </td>
                                <td>
                                <input type="checkbox" name="mwle"
                                <?php
                                        if($a["WIN"]["MWLE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> MWLE
                                </td>
                        </tr>

                </table>
                </fieldset>
                <fieldset>
                        <legend>LINUX</legend>
                <table style="white-space:nowrap;">
                          <tr>
                                <td width="200px">
                                <input type="checkbox" name="lfile_av"
                                 <?php
                                        if($a["LINUX"]["LINUXFILEAV"] == 1)
                                        {
                                                echo "checked";
                                        }
					 ?>
                                /> LINUXFILEAV
                                </td>
                                <td>
                                <input type="checkbox" name="linuxods"
                                 <?php
                                        if($a["LINUX"]["LINUXODS"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXODS
                                </td>
                          </tr>
                          <tr>
                                <td width="200px">
                                <input type="checkbox" name="lschedule"
                                 <?php
                                        if($a["LINUX"]["LINUXSCHEDULE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXSCHEDULE
                                </td>
                                <td> <input type="checkbox" name="lschedule_update"
                                 <?php
                                        if($a["LINUX"]["LINUXSCHEDULEUPDATE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXSCHEDULEUPDATE
                                </td>
                          </tr>
                 </table>
                </fieldset>
                <table>
		<tr>
                                <td> <input type="submit" value="Save" name="save"/><td>
                        </tr>
                </table>
                </form>
                </td>
                </tr>
        </table>
        </center>
</body>
</html>

