<?php
$host = "localhost";
$user = "root";
$password = "root123";
$dbname = "studentdb";
$con = mysql_connect($host,$user,$password);
if($con)
{
	mysql_select_db($dbname,$con);
}
else
{
	echo "Failed to Connect:".mysql_error();
}
?>
