<?php

	$case = $_POST['case'];

	$name = $_POST['name'];
	$roll = $_POST['roll'];
	$contact = $_POST['contact'];


	$servername="localhost";
	$user="root";
	$password="root123";
	$dbname="studentdb";

	$con=mysql_connect($servername,$user,$password);
	mysql_select_db($dbname);

	if(!$con)
	{
		die("Connection Failed");
	}

	if($case=='insert')
	{
 		$sql="insert into student_info (roll_no,name,contact) values ($roll,'$name','$contact')";
		$res=mysql_query($sql,$con);
		if(!res)
		{
			die("Query Failed");
		}

		$sql1 = "SELECT * FROM student_info";

		$result = mysql_query($sql1,$con);
		echo "<table class='table1' border='1' id='myTable'>";
		echo "<thead>";

		echo "<tr><th>&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>Roll No </th> <th>Name</th><th>Contact</th></tr>";
		echo "</thead>";
		echo "<tbody class='tbody'>";

		while($row = mysql_fetch_assoc($result))
		{
			echo "<tr>";
			echo "<td> <input name='checkbox' class='msg' value='".$row['roll_no']."' type='checkbox' 
					onclick='swap()'> </td> ";
			echo "<td>".$row['roll_no']."</td>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['contact']."</td>";
			
			echo "</tr>";
		}
		echo "</table>";
	
	}

	if($case=='display')
	{
		$sql = "SELECT * FROM student_info";
		$result = mysql_query($sql,$con);
		echo "<table class='table1' border='1px lightgrey ' id='myTable'>";
		echo "<thead>";

		echo "<tr><th></th> <th>Roll No </th> <th>Name</th><th>Contact</th></tr>";
		echo "</thead>";
		echo "<tbody class='tbody'>";

		while($row = mysql_fetch_assoc($result))
		{
			echo "<tr>";
			echo "<td width=\"1%\"> <input name='checkbox' class='msg' value='".$row['roll_no']."' type='checkbox'
					 onclick='swap()'> </td>";

			echo "<td>".$row['roll_no']."</td>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['contact']."</td>";
			echo "</tr>";
		}
		echo "</tbody>";

		echo "</table>";
	}
	if($case=='fetch')

	{
		$arr=array();
		$roll=$_POST['chkvalue'];
		$sql="SELECT * FROM student_info WHERE roll_no='$roll'";
		$res=mysql_query($sql,$con);
		$row=mysql_fetch_assoc($res);
		$arr[0]=$row['roll_no'];
		$arr[1]=$row['name'];
		$arr[2]=$row['contact'];
		echo json_encode($arr);

	}

	if($case=='update')

	{
		$old_roll=$_POST['old_roll'];
		$sql="UPDATE student_info SET roll_no=$roll,name='$name',contact='$contact' WHERE roll_no=$old_roll";
		$res=mysql_query($sql,$con);
		if(!res)
		{
			die("Query Failed");
		}

		$sql1 = "SELECT * FROM student_info";

		$result = mysql_query($sql1,$con);
		echo "<table class='table1' border='1' id='myTable'>";
		echo "<thead>";

		echo "<tr><th></th> <th>Roll No </th> <th>Name</th><th>Contact</th></tr>";
		echo "</thead>";
		echo "<tbody class='tbody'>";

		while($row = mysql_fetch_assoc($result))
		{
			echo "<tr>";
			echo "<td> <input name='checkbox' class='msg' value='".$row['roll_no']."' type='checkbox' 
					onclick='swap()'> </td> ";
			echo "<td>".$row['roll_no']."</td>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['contact']."</td>";
			
			echo "</tr>";
		}
		echo "</tbody>";

		echo "</table>";
	
	}
	if($case=='delete')
	{
		$roll=$_POST['roll_no'];
		$arr=explode(',',$roll);
		for($i=0;$i<count($arr)-1;$i++)
		{
			$sql="DELETE FROM student_info WHERE roll_no=$arr[$i]";
			$res=mysql_query($sql,$con);
		}
		if(!res)
		{
			die("Query Failed");
		}

		$sql1 = "SELECT * FROM student_info";

		$result = mysql_query($sql1,$con);
		echo "<table class='table1' border='1' id='myTable'>";
		echo "<thead>";
		echo "<tr><th></th> <th>Roll No </th> <th>Name</th><th>Contact</th></tr>";
		echo "</thead>";
		echo "<tbody class='tbody'>";

		while($row = mysql_fetch_assoc($result))
		{
			echo "<tr>";
			echo "<td> <input name='checkbox' class='msg' value='".$row['roll_no']."' type='checkbox' 
					onclick='swap()'> </td> ";
			echo "<td>".$row['roll_no']."</td>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['contact']."</td>";
			
			echo "</tr>";
		}
		echo "</tbody>";

		echo "</table>";

	}

	if($case=='check_duplicate')
	{
		$sql="SELECT * FROM student_info WHERE roll_no=$roll";
		$result=mysql_query($sql,$con);
		$rows=mysql_num_rows($result);
		if($rows > 0)
		{
			echo "<h3 style='color:red'>This Roll-No Already Exist!</h3>";
			
		}
	}
	
	if($case == 'search')
	{
		$search=$_POST['searchval'];	
		$sql="SELECT * FROM student_info WHERE roll_no='$search' OR name LIKE '%$search%' OR contact='$search'";
		$result=mysql_query($sql,$con);
		
		if(mysql_num_rows($result) > 0)
		{	
			echo "<center><p><b><font size='4'>Search Result</font></b></p></center>";
			echo "<b>You Search For-<font color='red' size='5'>".$search."</font></b>";
			echo "<table class='table1' border='1' id='myTable'>";
			echo "<thead>";
			echo "<tr><th>Roll No</th><th>Name</th><th>Contact</th></tr>";
			echo "</thead>";
			echo "<tbody class='tbody'>";
			while($row=mysql_fetch_assoc($result))
			{
				echo "<tr>";
				echo "<td>".$row['roll_no']."</td>";
				echo "<td>".$row['name']."</td>";
				echo "<td>".$row['contact']."</td>";
				echo "<tr>";
			}
			echo "</tbody>";
			echo "</table>";
		}
		else
		{
			echo "<center><h4> Your Search-<font color='red' size='5'>".$search."</font>
				-did not match with any record.</h4><center>";
		}
		
	}

?>
