<?php
function test1()
{
	echo "XYZ";
	function test2()
	{
		echo "sdc";
	}
	test2();
}
test1();
?>
