<?php
function ini_read()
{
	$file=fopen("abc.ini","r");
	$arr=array();
	if($file)
	{
		while(!feof($file))
        	{
        		$data=trim(fgets($file));
			if(strpos($data,"[")===0)
			{
				$section=trim($data,"[");
				$sec=trim(str_replace("]",'',$section));
				$arr[$sec]=array();
			}
			else
			{	if($data !="")
				{
				$raw=explode("=",$data);
				$key=trim($raw[0]);
                        	$value=trim($raw[1]);
				$val=trim(str_replace('"','',$value));
				$arr[$sec][$key]=trim($val);
				}
			}
		}
	fclose($file);
	return $arr;	
	}
	else
	{
		echo "File not Found.";
	}
}	
$a=ini_read();
function ini_write($arr)
{
	if($arr)
	{
		$file=fopen("abc_w.ini","w+");
		$delim = '"';
		if($file)
		{
			$sec_arr=array_keys($arr);
			foreach($sec_arr as $sec)
			{
				$sec_arr_keys = array_keys($arr[$sec]);
				fwrite($file,"[$sec]\n");
				foreach($sec_arr_keys as $val)
				{
					$data = $arr[$sec][$val];
					fwrite($file,"$val=$delim$data$delim\n");
				
				}
			}
		fclose($file);
		}
		else
		{
			echo "Error in writing File";
		}
	}
}
ini_write($a);
?>
