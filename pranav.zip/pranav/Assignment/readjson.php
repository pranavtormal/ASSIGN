<?php
$xml = simplexml_load_file("firewall-rules.xml") or die("Error");
//var_dump($xml);
$option = $_POST['id'];
if($option != "" && $option == "read")
{
	$jdata = json_encode($xml);
	//var_dump($jdata);
	echo $jdata;

}
?>
