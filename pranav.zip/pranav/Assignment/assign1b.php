<!DOCTYPE html>
<html>
<head>
	<title>Student Information</title>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
<script>

	function validator()
	{
 		var name=$("#name").val();
		//alert(name); for checking textfied value
		var roll=$("#rno").val();
		var contact=$("#contact").val();
		if( name==null || name =="" || contact ==null || contact =="" || roll ==null || roll =="" )
		{
	

			var a=document.getElementById('name').value;
			if(a==null || a=="")
			{
				alert("Enter Name");
				return false;

			}

			var b=document.getElementById('rno').value;
			if(b==null || b=="")
			{
				alert("Enter Roll No");
				return false;
			}	

			var c=document.getElementById('contact').value;
			if(c==null || c=="")
			{
				alert("Enter Contact No");
				return false;
			}

			if(c.lenght<10)
			{
				alert("Enter 10 digits");
				document.getElementById('contact').value="";
				return false;
			}
		
		
		}
		else

		{
			$.ajax({
				type:'post',
				url:'info1.php',
				//data:"name="+name+"&roll="+roll+"&contact="+contact, //Alternate Way To send Data
				data:{'name':name,'roll':roll,'contact':contact},
				success:function(response)
				{
					//alert(response);//To check response
					$('#sp').html(response);
				}

		   	       });
		}	
        }




	function checkName(name)
	{
	
		var letters = /^[A-Za-z\s]+$/;
		if(!name.match(letters))
		{
			alert("Enter only Characters");
			document.getElementById('name').value="";
		}
		if(name.length>=21)
		{
			alert("Enter less than 20 Characters");
		}
	} 
	function checkRoll(roll)
	{
	
		var digits = /^[0-9]+$/;
		if(!roll.match(digits))
		{
			alert("Enter only digits");
			document.getElementById('rno').value="";
		}
		if(roll.length>4)
		{
			alert("Enter less than 4 Digits");
			document.getElementById('rno').value="";
		} 
	}

	function Checkcontact(contact)
	{
		var digit=/^[0-9]+$/;
		if(!contact.match(digit))
		{
			alert("Enter Only Digits");
			document.getElementById('contact').value="";
		}
		if(contact.length>11)
		{
			alert("Enter 10 Digits Contact No ");
			document.getElementById('contact').value="";

		}
		if(contact.length<10)
		{

		 	alert("Enter 10 Digits Contact No");
			document.getElementById('contact').value="";
		}
	}
</script>
<head>
<body>
<center><fieldset>

	<legend align="center"><h3 style="color:green">Student Information</h3></legend>
		<form name='mform' id="mform" >
       		 <table style="background:grey">
       			 <tr>
        			<td><b>Name:</b></td>
        			<td><input type="text" name="name" id="name" autocomplete="off" onkeyup="checkName(this.value)"/> 				</td>
        		</tr>
        		<tr>
        			<td><b>Roll No:</b></td>
        			<td><input type="text" name="rno" id="rno" autocomplete="off" onkeyup="checkRoll(this.value)"/>  				 </td>
        		</tr>
        		<tr>
        			<td><b>Contact No:</b></td>
        			<td><input type="text" name="contact" id="contact" autocomplete="off" 
				onblur="Checkcontact(this.value)"/></td>
        		</tr>
        		<tr>
				<td><input type="button" value="Submit" style="font-weight:bold" onclick="validator()"/></td>
			</tr>
       		 </table>
			<span id="sp"> </span>

</fieldset></center>
</body>
</html>
