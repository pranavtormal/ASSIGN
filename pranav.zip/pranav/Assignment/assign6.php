<html>
<head>
	<title>File Operations</title>
</head>
<body>
	<form action="" method="post">
	<center>
	<h3><font color="green">File Operations</font></h3>
	<table border="1">
	<tr>
		<td rowspan="3"><input type="text" name="val" autocomplete="off"/ autofocus></td>
		<td><input type="submit" value="Replace" name="replace"/></td>
	</tr>
	<tr>
		<td><input type="submit" value="Delete" name="delete"/></td>
	</tr>
	<tr>
		<td><input type="submit" value="insert" name="insert"/></td>
	</tr>
	</table>
	</center>
	</form>
</body>
</html>
<?php
	if($_POST['replace'])
	{
		$val = trim($_POST['val']);
		$len = strlen($val);
		$replace = "xyz";
		$arr = array();
		if($val !="")
		{
			$file = fopen("abc.txt","r");
			//$path = "/opt/MicroWorld/var/www/htdocs/pranav/Assignment/abc.txt";
			if($file)
			{
		
				/*
				$file_contents = file_get_contents($path);
				$file_contents = str_replace($val,$replace,$file_contents);
				file_put_contents($path,$file_contents);
				*/
				while(!feof($file))
				{
					$data = trim(fgets($file));
					$position = strpos($data,$val);
					if($position !="")
					{
						$data = str_replace($val,$replace,$data);
						array_push($arr,$data);
					}
					else
					{
						array_push($arr,$data);
					}
					
				}
				fclose($file);
				$file1 = fopen("abc.txt","w");
				foreach($arr as $key)
				{
					fwrite($file1,"$key\n");
				}
				fclose($file1);
			}
			else
			{
			echo "File not found.";
			}	
			
		}
	}
	if($_POST['insert'])
	{
		$val = trim($_POST['val']);
		if($val !="")
		{
			$file = fopen("abc.txt","a");
			if($file)
			{
		
				fwrite($file,"\n$val");
				//fwrite($file,"$val");
			}
			else
			{
				echo "File not Found";
			}
		}
		fclose($file);

	}
	if($_POST['delete'])
	{
		$val = trim($_POST['val']);
		$arr = array();
		if($val !="")
		{
			$file = fopen("abc.txt","r");
			if($file)
			{
				while(!feof($file))
				{
					 $data = trim(fgets($file));
                                 	$position = strpos($data,$val);
                                 	if($position !="")
                                 	{
                                 		$data = str_replace($val,"",$data);
                                 		$arr[] = $data;
                                 	}
					else
					{
						$arr[] = $data;		
					}
					/*
					if(preg_match("/$val/",$data))
					{
						$data = str_replace($data,"",$data);
						fwrite($file,$data);
					}*/
				}
				fclose($file);
				$file1 = fopen("abc.txt","w");
				foreach($arr as $key)
				{
					fwrite($file1,"$key\n");
				}
				fclose($file1);
			}
			else
			{
				echo "File not found";
			}
		}	
	}
	
?>


