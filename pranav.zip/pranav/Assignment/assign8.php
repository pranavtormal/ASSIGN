<?php
$xml = simplexml_load_file("firewall-rules.xml") or die("Error");
//var_dump($xml);
if($xml)
{	
	$con = mysql_connect("localhost","root","root123");
	mysql_select_db("studentdb",$con);
	if(!$con)
	{
		die("Connection Failed");
	
	}
	$jdata = json_encode($xml);
	print_r($jdata);
	//echo "<br/>";
	$jarr = json_decode($jdata,true);
	//var_dump($jarr);
	$data = serialize($jarr);
	//$len = strlen($data);
	//echo "$len<br/>"
	/*
	if($data != "")
	{
		$sql= "INSERT INTO xml_data values('','$data')";
        	mysql_query($sql,$con);
	}
	*/
	$sql = "select * from xml_data";
	$res = mysql_query($sql,$con);
	$row = mysql_fetch_assoc($res);
	$a = $row['rule'];
	//echo "$a";
	
	/*
	foreach($jarr as $firewall)
	{
		foreach($firewall as $rule)
		{
			//print_r($rule);
			//echo "<br/>";
			$data = serialize($rule);
			//echo "$data";
			//echo "<br/>";
			//$sql= "INSERT INTO xml_data values('','$data')";
			//mysql_query($sql,$con);
		}
	}
	*/
	mysql_close($con);

}
?>
