<html>
<head>
	
	<script src="jquery-1.7.1.min.js"></script>
	<script>
		$(document).ready(function(){
			//alert("djfkd");
			$.ajax({
				type:'post',
				url:'readjson.php',
				data:{'id':'read'},
				success:function(resp)

				{
					var jdata = JSON.parse(resp);
					console.log(resp);
					//console.log(jdata.rule);
					//console.log(Object.keys(jdata.rule[0]));
					//console.log(jdata.rule[0]['ip-source-address']['@attributes']['type']);
					var len = Object.keys(jdata.rule).length;// total no of rules
					//console.log(jdata.rule[0]['@attributes']['name']);
					//var t = "ip-source-port";
					//console.log(jdata.rule[0][t]['@attributes']['type']);
					for(var i=0;i<len;i++)
					{	console.log(i);
						var first = jdata.rule[i]['@attributes']; //array of attributes
						for(var id in first)
						{	//console.log(id);
							//console.log(jdata.rule[i]['@attributes'][id]);
							var name = jdata.rule[i]['@attributes'][id];//get the value of attributes
							//console.log(name);
							document.getElementById('myDiv').innerHTML +=id +":"+name+"<br>";
						}
						var child = Object.keys(jdata.rule[i]);
						//console.log(child);
						for(var r=0;r<child.length;r++)
						{		
							var c = child[r];
							//console.log(c);
							if(c == "process-icmp")
							{
								var sec = jdata.rule[i][c];	
							}
							else
							{
								//console.log(c);
								if(c != "undefined")
								{
									var sec = jdata.rule[i][c]['@attributes'];
								}
							}
						
                                                	for(var n in sec)
                                                	{	//console.log(n);
                                                        	//console.log(jdata.rule[i]['ip-source-address']['@attributes'][n]);
								if(c == "process-icmp" || c == "process-icmpv6")
								{
									var name5 = jdata.rule[i][c][n];
									//console.log(name5);
                                                        		document.getElementById('myDiv').innerHTML +=n +":"+name5+"<br>";
								}
							
								else
								{
									var name1 = jdata.rule[i][c]['@attributes'][n];
									//console.log(name1);
									document.getElementById('myDiv').innerHTML +=n +":"+name1+"<br>";
								}
                                                	}
						}
					}
				
				}
			});
		
		});
		
	</script>
</head>
<body>
	<div id="myDiv" style="height:100%;overflow:auto;">
	</div>
</body>
</html>
