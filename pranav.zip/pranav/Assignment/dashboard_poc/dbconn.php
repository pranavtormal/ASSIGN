<?php

$host = "localhost";
$user = "root";
$password = "root123"; 
$dbname = "studentdb"; // database name

$con = mysql_connect($host,$user,$password);
if($con)
{
	mysql_select_db($dbname,$con);
}
else
{
	echo json_encode('Failed to Connect');
}

?>
