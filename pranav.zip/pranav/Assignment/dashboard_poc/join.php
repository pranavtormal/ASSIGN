<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/dashboard.css" />
	<script src="jquery-1.7.1.min.js"></script>
        <script src="highcharts.js"></script>
	<script type="text/javascript" src="js/dashboard.js"></script>

</head>
<body class="userSelect">
	<div id="outerDiv" class="outerDiv">
		<div id="optionDiv" class="optionDiv">
			<div id="dragOptionMainDiv" class="dragOptionMainDiv">
					<table class="dragOptionTable">
						<tr style="background-color:#CCFF99">
							<td align="center"><small>Type Of Graph</small></td>
							<td align="center"><input class="barType" style="vertical-align:middle;" id="barOnly" onchange="showBar()" type="checkbox" value="bar"/> <small>Bar Graph</small> </td>
							<td align="center"><input class="barType" style="vertical-align:middle;" id="pieOnly" onchange="showPie()" type="checkbox" value="pie"/><small>Pie Chart</small></td>
							<td align="center"><input class="barType" style="vertical-align:middle;" id="bothBar" onchange="showBoth()" type="checkbox" value="both"/> <small>Both</small></td>
						</tr>
					</table>
                                        <table id="dragOptionTable"  border="1" class="dragOptionTable">
                                                <tr>
                                                        <th width="250px;height:30px"><small>Drag Option List</small></th>
                                                        <th width="300px;height:30px"><small>Drop Hrere</small></th>
                                                        <th style="height:30px"><small>Date</small></th>
                                                </tr>
                                        </table>
					<table style="white-space:nowwrap">
					<tr>
					<td>
                                        	<div  id="dragOptionLeftDiv" style="height:80px;width:251px;border:1px solid grey;float:left;overflow:auto">
                                                	<ul id="Ulist">
                                                
                                                	</ul>
                                        
                                        	</div>
					</td>
					<td>
                                        	<div id="dragOptionMiddleDiv" style="height:80px;width:302px;border:1px solid grey;margin-left:-2px;float:left">
                                                	<input type="text" id="drop" ondrop="drop(event)" ondragover="allowDrop(event)" style="height:25px;width:250px;margin-top:18px;margin-left:20px;border-radius:10px" readonly/>
                                                 	<center><span id="alertSpan" style="color:red"></span></center>
                                        	</div>
					</td>
					<td style="white-space:nowrap">
						 <div id="dragOptionRightDiv"style="height:80px;width:230px;border:1px solid grey;overflow:auto;float:left;margin-left:-1px">
                                                
                                        	</div>
					</td>
					</tr>
					</table>
					 <center>
						<button id="btnOk" style="height:35px;width:150px;border-radius:8px;cursor:pointer;white-space:nowrap;background-color:green;color:white;" onclick="generateGraph()"> Generate</button>
					</center>
				</div><!--dragOptionDiv end here-->
		</div><!--optionDiv end here-->
		<div id="blankGraphDiv" class="blankGraphDiv">
			<table width="935px" height="100%"  border="1" style="margin-top:20px;table-layout:fixed">
				<tr id="r1" style="height:400px">
					<td>
						<div id="barGraphTd" style="width:925px">
						</div>
					</td>
				
				</tr>
				<tr id="r2" style="height:466px;display:none;overflow:hidden">
                                   
					<td id="td1" width="300px" class="pieTd">
						<h5 style="text-align:center">Price Range Between 200 to 300</h5>
						<div style="width:300px;" id="pie1Td">
						
						</div>
						
					</td>
					<td  id="td2" width=" 300px" class="pieTd">
						<h5 style="text-align:center">Price Range Between 301 to 400</h5>
						 <div style="width:300px" id="pie2Td">
                                                </div>
					</td>
					<td id="td3" width="300px" class="pieTd">
						<h5 style="text-align:center">Price Range Between 401 to 500</h5>
						 <div style="width:310px;" id="pie3Td">
                                                </div>
					</td>
                                </tr><!--end of 2nd tr -->
			</table>
		</div><!-- blankGraphDiv end here-->
	
	<div><!--outerDiv end here-->
</body>
</html>
