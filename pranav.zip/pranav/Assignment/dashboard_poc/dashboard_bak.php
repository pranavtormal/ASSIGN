<!DOCTYPE html>
<html>
<head>
	<meta content="text/html" charset="UTF-8"/>
	<title>Student Dashboard</title>
	<style>
		.outerDiv{
			height:745px;
			width:1300px;
			border:1px solid grey;
			margin:0 auto;
			background:#CCCCFF;
			overflow:auto;
		}
		.studentInfoTable{
			height:50px;
			width:100%;
			margin:auto;
			user-select:none;
			-moz-user-select: none;
			-webkit-user-select:none;
			-ms-user-select:none;
		}
		 .studentInfoTable th{
			background:#3399FF;
			height:40px;
		}
		 .studentInfoTable td{
                        text-align:center;
			font-weight:bold;
                }
		.innerDiv{
                        height:650px;
                        width:1250px; 
                        margin:0 auto;
			margin-top:30px;
                       
                }
		.studentRollDiv{
			height:50px;
                        width:100px;
			float:right;
		}
		.avgGradeDiv{
			margin-top:20px;
			height:428px;
			border-radius:10px;
		}
		.avgGradeLeftDiv{
			border:1px solid blue;
                        height:428px;
			width:615px;
			float:left;
                        background:white;
                        border-radius:10px;
		}
		.avgGradeRightDiv{
                        border:1px solid blue;
                        height:428px;
                        width:615px;
			float:right;
                        background:white;
                        border-radius:10px;
                }
		.mPieDiv{
			border:1px solid blue;
                        height:250px;
                        width:407px;
                        background:white;
                        border-radius:8px;
		}
		.dragOptionDiv{
			width:615px;	
		}
		#Ulist li{
			margin:auto;
			list-style-type: none;	
			font-size:20px;
			font-weight:bold;
			margin-left:30px;
			cursor:grab;
			cursor:-moz-grab;
			cursor:-webkit-grab;
			cursor:-ms-grab;
		}
		.dragOptionMainDiv{
			width:800px;
			height:155px;
			border:1px solid grey;
			margin:auto;
		}
		.dragOptionTable{
			width:100%;
			border:1px;
			-moz-user-select: none;
			-webkit-user-select:none;
			-ms-user-select:none;
		}
		#Ulist{
			-moz-user-select: none;
			-webkit-user-select:none;
			-ms-user-select:none;
		}
		
	</style>
	<script src="jquery-1.7.1.min.js"></script>
	<script src="Chart.js"></script>
	<script src="highcharts.js"></script>
	<script src="text/javascript">

		$(document).ready(function(){
	
			function drawHighChartBar(id,Title,data,roll,chartType,yAxis) //function to draw Charts
                        {
				$(id).highcharts({
                                	chart:{
                                             	type:chartType,
                                              },
                                        title:{
                                                text:Title
                                              },
                                        xAxis:{
                                              	categories:roll,

                                              },
                                       	yAxis,
                                       legend:{
                                              	reversed:true
                                              },
                                       series:data
                                });
                        } //drawHighChartBar end here
			var total =0;
			function avgMark(arr)  //function to calculate sum of array element
                       	{
                        	$.each(arr,function(){
                                	total += this;
                                });
                                return total;
                        } //avgMarks function end here
			
			var roll =$('#rollOption').val();
			if(roll !=null && roll != " " && roll != undefined )
                        {
                                $.ajax({
                                        type:'GET',
                                        url:'getdata.php',
                                        contentType:'application/json',
                                        dataType:'json',
                                        data:{"roll":roll,"case":0},
                                        success:function(response){
						//console.log(response);			
						var name = [];
						var m11 = [];
                                                var m22 = [];
                                                var m33 = [];
                                                var grade1 = [];
						var rollNo = [];
						var class1 = []

						response.map(function(a)
						{
							
							m11.push(parseInt(a.m1));
							m22.push(parseInt(a.m2));
							m33.push(parseInt(a.m3));
							grade1.push(parseFloat(a.grade));
							rollNo.push("RollNo-"+a.roll_no);
							class1.push(a.class);
							name.push(a.name);
						});
						
						for(var i=0;i<rollNo.length;i++)
						{
							$('#studentInfoTable').append('<tr class="rmrow"><td>'+name[i]+'</td><td>'+class1[i]+'</td><td>'+m11[i]+'</td><td>'+m22[i]+'</td><td>'+m33[i]+'</td><td>'+grade1[i]+'</td></tr>');
						}

						var data = [{name:'M1',data:m11},{name:'M2',data:m22},{name:'M3',data:m33},{name:"Grade",data:grade1}];	
						var chartType = "column";
						var Title = "Maths marks Bar Chart";
						var yAxis =  {
                                                                        min:0,
                                                                        max:100,
                                                                }
						var id = $('#avgGradeLeftDiv');
						drawHighChartBar(id,Title,data,rollNo,chartType,yAxis); //All columns
					
						var id = $('#avgGradeRightDiv');
						var chartType = "line";
						var Title = "Maths marks Line Chart";
						drawHighChartBar(id,Title,data,rollNo,chartType); //line Chart

						var m1Sum = avgMark(m11);// function call 
						var avgm1 = (m1Sum) / (m11.length);
						var remainM1 = 100 - avgm1;

						total = 0;//make total =0 everytime
						var m2Sum = avgMark(m22);
						var avgm2 = (m2Sum) / (m22.length);
						var remainM2 = 100 - avgm2;
						remainM2 = parseFloat(remainM2.toFixed(2)); //keep only 2 decimal
					
						total = 0;
						var m3Sum = avgMark(m33);
						var avgm3 = (m3Sum) / (m33.length);
						var remainM3 = 100 - avgm3;
						remainM3 =  parseFloat(remainM3.toFixed(2));
						
						var id = $('#m1PieDiv');
						chartType = "pie";
						Title = "M1 Avg Pie Chart";
						data = [{name:"AVG",data:[{name:"M1",y:avgm1},{y:remainM1}]}];
						drawHighChartBar(id,Title,data,rollNo,chartType);// function call for pie chart m1
						var id = $('#m2PieDiv');
						Title = "M2 Avg Pie Chart";
						data = [{name:"AVG",data:[{name:"M2",y:avgm2},{y:remainM2}]}]
						drawHighChartBar(id,Title,data,rollNo,chartType); // m2 Pie chart
						
						var id = $('#m3PieDiv');
                                                Title = "M3 Avg Pie Chart";
                                                data = [{name:"AVG",data:[{name:"M3",y:avgm3},{y:remainM3}]}]
                                                drawHighChartBar(id,Title,data,rollNo,chartType); // m2 Pie chart 
                                        } //success function end here
                                }); //ajax end here
                        } //if loop end here 	
		}); //ready function end here
		
		function getColumn()
		{
			var col = document.getElementById('drop').value;
			//alert(col);
			document.getElementById("alertSpan").innerHTML = ""; 
			var rollNo = $('#rollOption').val();

			if(rollNo == "All") //get all records
			{
				rollNo = "1a";
			}
		
			var col = col.trim();
			if(col)
			{
				var str = col.replace(/,\s*$/,""); //remove last ,
				var dragElement = str.split(",");
				
				for(var i=0;i < dragElement.length;i++) //append dropped element to DragOption list
				{
					$('#Ulist').append('<li id='+ dragElement[i] +' draggable=true ondragstart=drag(event)>'+dragElement[i].toUpperCase()+'<li>');
				}
				document.getElementById('drop').value = "";
				
				
				$.ajax({
					type:'GET',
					url:'getdata.php',
					contentType:'application/json',
					dataType:'json',
					data:{"col":str,"roll":rollNo},
					success:function(resp){
						var key;
						var obj;
						var m1 = [];
						var m2 = [];
						var m3 = [];
						var grade = [];
						var roll_array = [];
						for(var i in resp)
						{	
							var obj1 = resp[i];
							//key = Object.keys(resp[i]);
							//obj = resp[i];
							
							if("m1" in obj1)
							{	
								m1.push(parseInt(obj1.m1));//push all m1 values in Int type
							}
							 if("m2" in obj1)
							{
								m2.push(parseInt(obj1.m2));//push all m2 values in Int type
							}
							 if("m3" in obj1)
							{
								m3.push(parseInt(obj1.m3));//push all m3 values in Int type
							}
							if("grade" in obj1)
							{
								grade.push(parseFloat(obj1.grade));//push all grade values in Float type
							}
							if("roll_no" in obj1)
							{
								roll_array.push("RollNo-"+obj1.roll_no); //push all roll no Int type
							}
					
						} //for loop end here

						var total = 0;
                                                function avgMark(arr)  //function to calculate sum of array element
                                                {
                                                        $.each(arr,function(){
                                                                 total += this;
                                                        });
                                                        return total;
                                                }
						
						var m1Sum = avgMark(m1);
                                                var avgm1 = (m1Sum) / (m1.length);
                                                var remainM1 = 100 - avgm1;
						
						total = 0;//make total =0 everytime
                                                var m2Sum = avgMark(m2);
                                                var avgm2 = (m2Sum) / (m2.length);
                                                var remainM2 = 100 - avgm2;
                                                remainM2 = parseFloat(remainM2.toFixed(2)); //keep only 2 decimal

                                                total = 0;
                                                var m3Sum = avgMark(m3);
                                                var avgm3 = (m3Sum) / (m3.length);
                                                var remainM3 = 100 - avgm3;
                                                remainM3 =  parseFloat(remainM3.toFixed(2));

						function highChartBar(id,Title,data,roll,chartType,yAxis) //function to draw Charts
                                                {

                                                        $(id).highcharts({
                                                                chart:{
                                                                        type:chartType,
                                                                },
                                                                title:{
                                                                        text:Title
                                                                },
                                                                xAxis:{
                                                                        categories:roll,

                                                                },
                                                                yAxis,
                                                                legend:{
                                                                        reversed:true
                                                                },
                                                                series:data
                                                        });
                                                }

						var Title = "Maths marks Bar Chart";
						var chartType ="column";
						var yAxis =  {
                                                                        min:0,
                                                                        max:100,
                                                                };
						//if only m1 selected
						if( m1.length > 0 && m1 != null && m2.length == 0 && m3.length == 0 && grade.length == 0)
						{
							var id = $('#avgGradeLeftDiv'); //target to display
							var data = [{name:'M1',data:m1}];
							highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
							var id = $('#avgGradeRightDiv');
                                                	var chartType = "line";
                                                	var Title = "Maths marks Line Chart";
                                                	highChartBar(id,Title,data,roll_array,chartType);//line chart
							var id = $('#m1PieDiv');
                                                	chartType = "pie";
                                               		Title = "M1 Avg Pie Chart";
                                                	data = [{name:"AVG",data:[{name:"M1",y:avgm1},{y:remainM1}]}];
                                                	highChartBar(id,Title,data,rollNo,chartType);// function call for pie chart m1

						}
						
						else if(m2.length > 0 && m2 != null && m1.length == 0 && m3.length == 0 && grade.length == 0) //if only m2 selected 
						{
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M2',data:m2}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
							var id = $('#m2PieDiv');
                                                        chartType = "pie";
                                                        Title = "M2 Avg Pie Chart";
                                                        data = [{name:"AVG",data:[{name:"M2",y:avgm2},{y:remainM2}]}];
                                                        highChartBar(id,Title,data,roll_array,chartType);// function call for pie chart m1
						}
						
						else if(m3.length > 0 && m3 != null && m1.length == 0 && m2.length == 0 && grade.length == 0) //if only m3 selected
						{
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M3',data:m3}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
							var id = $('#m3PieDiv');
                                                        chartType = "pie";
                                                        Title = "M3 Avg Pie Chart";
                                                        data = [{name:"AVG",data:[{name:"M3",y:avgm3},{y:remainM3}]}];
                                                        highChartBar(id,Title,data,roll_array,chartType);// function call for pie chart m1
						}
						else if(grade.length > 0 && grade != null && m1.length == 0 && m2.length == 0 && m3.length == 0)// if only grade selected
						{
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'Grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
						}
						// if m1 & m2 selected
						else if(m1.length > 0 && m2.length > 0 && m3.length == 0 && grade.length == 0)
						{
						
                                                       	var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M1',data:m1},{name:'M2',data:m2}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
						}
						//if m1 & m3 selected
						else if(m1.length > 0 && m3.length > 0 && m2.length == 0 && grade.length == 0)
						{
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M1',data:m1},{name:'M3',data:m3}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
						}
						//if m1 and grade selected
						else if(m1.length > 0 && grade.length > 0 && m2.length == 0 && m3.length == 0)
                                                {
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M1',data:m1},{name:'Grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						//if m2 & m3 selected
						else if(m2.length > 0 && m3.length > 0 && m1.length == 0 && grade.length == 0)
                                                {
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M2',data:m2},{name:'M3',data:m3}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						//if m2 and grade selected
						else if(m2.length > 0 && grade.length > 0 && m1.length == 0 && m3.length == 0)
                                                {
                                                        var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M2',data:m2},{name:'Grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						// if m3 & grade selected
						else if(m3.length > 0 && grade.length > 0 && m2.length == 0 && m1.length == 0)
                                                {
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M3',data:m3},{name:'Grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						//if m1,m2,m3 selected
						else if(m1.length > 0 && m2.length > 0 && m3.length > 0 && grade.length == 0)
                                                {
                                                        var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M1',data:m1},{name:'M2',data:m2},{name:'M3',data:m3}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
                                                        highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						//if m1,m2,grade selected
						else if(m1.length > 0 && m2.length > 0 && grade.length > 0 && m3.length == 0)
                                                {
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M1',data:m1},{name:'M2',data:m2},{name:'Grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
							 highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						//if m1,grade,m3 selected
						else if(m1.length > 0 && grade.length > 0 && m3.length > 0 && m2.length == 0)
                                                {
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M1',data:m1},{name:'M3',data:m3},{name:'grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
							 highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						//if m2,grade,m3 selected
						else if(m2.length > 0 && grade.length > 0 && m3.length > 0 && m1.length == 0)
                                                {
							var id = $('#avgGradeLeftDiv');
                                                        var data = [{name:'M2',data:m2},{name:'M3',data:m3},{name:'Grade',data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
							 highChartBar(id,Title,data,roll_array,chartType);//line chart
                                                }
						else
						{
							var id = $('#avgGradeLeftDiv');
							var data = [{name:'M1',data:m1},{name:'M2',data:m2},{name:'M3',data:m3},{name:"Grade",data:grade}];
                                                        highChartBar(id,Title,data,roll_array,chartType,yAxis);//column chart
                                                        var id = $('#avgGradeRightDiv');
                                                        var chartType = "line";
                                                        var Title = "Maths marks Line Chart";
							 highChartBar(id,Title,data,roll_array,chartType);//line chart
						}
						

					} //success function end here
				}); //ajax end here
				
			}
			else
			{
				document.getElementById("alertSpan").innerHTML = "Drag and Drop Column"; 
			}	
			
		}//getColumn function end here
		
		function getDetail()
		{
			var rollN = $('#rollOption').val();

			$.ajax({
				type:'GET',
				url:'getdata.php',
				dataType:'json',
				data:{"roll":rollN,"case":1},
				success:function(resp){
					$('.rmrow').remove(); //remove previous records
					for (var j=0;j < resp.length;j++)
					{
						$('#studentInfoTable').append('<tr class="rmrow"><td>'+resp[j].name+'</td><td>'+resp[j].class+'</td><td>'+resp[j].m1+'</td><td>'+resp[j].m2+'</td><td>'+resp[j].m3+'</td><td>'+resp[j].grade+'</td></tr>');
					}
				}
			});//ajax end here
		}//function getDetails end here

		function allowDrop(ev) 
		{
			 ev.preventDefault(); //stop browser default action
		}

		function drag(ev)
		{
    			ev.dataTransfer.setData("text", ev.target.id); //get id of draggable element
		}

		function drop(ev) 
		{
    			ev.preventDefault();
    			var data = ev.dataTransfer.getData("text"); //get id of element
			
			document.getElementById("drop").value += data + ','; //get value in textbox	
    			//ev.target.appendChild(document.getElementById(data));//append element into target
			document.getElementById(data).remove(); //remove element if only element's value required
			
		}

	</script>
</head>

<body>
	<div id="outerDiv" name="outerDiv" class="outerDiv">
		<div id="innerDiv" name="innerDiv" class="innerDiv">
			<div id="studentInfoDiv" name="studentInfoDiv" style="height:276px;border:1px solid grey;" >
				<div id="dragOptionMainDiv" class="dragOptionMainDiv">
					<table id="dragOptionTable"  border="1" class="dragOptionTable">
						<tr>
							<th width="250px;height:30px">Drag Option List</th>
							<th width="300px;height:30px">Drop Hrere</th>
							<th style="height:30px">Student Roll</th>
						</tr>
					</table>
					<div  id="dragOptionLeftDiv" style="height:80px;width:253px;border:1px solid grey;float:left;overflow:auto">
						<ul id="Ulist">
                                                <li draggable="true" ondragstart="drag(event)" id="m1">M1</li>
                                                <li draggable="true" ondragstart="drag(event)" id="m2">M2</li>
                                                <li draggable="true" ondragstart="drag(event)" id="m3">M3</li>
                                                <li draggable="true" ondragstart="drag(event)" id="grade">Grade</li>
						</ul>
                                        </ul>
					</div>
					<div id="dragOptionMiddleDiv" style="height:80px;width:304px;border:1px solid grey;margin-left:2px;float:left">
						<input type="text" id="drop" ondrop="drop(event)" ondragover="allowDrop(event)" style="height:25px;width:250px;margin-top:18px;margin-left:20px;border-radius:10px" readonly/>
                                        	 <center><span id="alertSpan" style="color:red"></span></center>
                                        </div>
					<div id="dragOptionRightDiv"style="height:80px;width:233px;border:1px solid grey;overflow:auto;float:right">
						<select id="rollOption" onchange="getDetail()" style="width:100px;height:30px;text-align:center;margin-top:18px;margin-left:50px">
							<option value="All">All</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							
						</select>
                                        </div>
					<center><button id="btnOk" style="height:35px;width:150px;border-radius:8px;background-color:green;color:white;cursor:pointer;" onclick="getColumn()"> Generate</button></center>
                        	</div>
				<div id="studentDetailsDiv" style="overflow:auto;height:100px;margin-top:20px">
			 		<table border="1" id="studentInfoTable" name="studentInfoTable" class="studentInfoTable">
                                		<tr>
                                        		<th width="300px">Name</th>
                                        		<th>Class</th>
                                        		<th>M1</th>
                                        		<th>M2</th>
                                        		<th>M3</th>
                                        		<th>Grade</th>
                                		</tr>

                        		</table>
				</div>
			</div> <!--end of studentInfoDiv-->
			<div id="avgGradeDiv" name="avgGradeDiv" class="avgGradeDiv">
				<div id="avgGradeLeftDiv" name="avgGradeLeftDiv" class="avgGradeLeftDiv">
					<canvas id= "barChart" style="height:100%;width:100%"></canvas>
				</div>
				<div id="avgGradeRightDiv" name="avgGradeRightDiv" class="avgGradeRightDiv">
					<canvas id= "rightBarChart" style="height:100%;width:100%"></canvas>
                                </div>
			</div>
			<div id="pieChartDiv" name="pieChartDiv" style="margin-top:10px" class="pieChartDiv">
				<div id="m1PieDiv" name="m1PieDiv" style="float:left" class="mPieDiv">
                                        <canvas id= "m1pieChart" style="height:100%;width:100%"></canvas>
                                </div>
				 <div id="m2PieDiv" name="m2PieDiv" style="float:left;margin-left:10px" class="mPieDiv">
                                        <canvas id= "m2pieChart" style="height:100%;width:100%"></canvas>
                                </div>
				 <div id="m3PieDiv" name="m3PieDiv" style="float:right" class="mPieDiv">
                                        <canvas id= "m3pieChart" style="height:100%;width:100%"></canvas>
                                </div>
			</div> <!--end of piechatDiv-->
		</div> <!--end of innerDiv-->
	</div>  <!--end of outrDiv-->
</body>
</html>
