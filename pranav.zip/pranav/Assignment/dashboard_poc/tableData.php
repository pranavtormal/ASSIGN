<?php
include_once("dbconn.php");
header("content-Type:application/json");

$case = trim($_GET['case']);
$out = array();
$col = array();
if($case == 0)
{
	//$sql = "SELECT * FROM information_schema.columns WHERE table_schema='studentdb'";
	$sql = "SELECT table_name,column_name FROM information_schema.columns where table_schema ='studentdb'";
	$result = mysql_query($sql,$con);
	if($result)
	{
		while($row = mysql_fetch_assoc($result))
		{
			$out[] = $row;
		}
		
		echo json_encode($out);
	}
	else
	{
		echo json_encode("Query Failed!");
	}
}
else
{
	echo json_encode("Case not valid");
}


?>
