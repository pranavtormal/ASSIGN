<?php

include_once("dbconn.php");
header('Content Type:application/json');
$method = $_SERVER['REQUEST_METHOD'];
$data = array(); 
$roll = trim($_GET['roll']);
$case = trim($_GET['case']);
//$chart = filter_var(trim($_GET['bar']),FILTER_SANITIZE_STRING);
$col = filter_var(trim($_GET['col']),FILTER_SANITIZE_STRING);

if($method == "GET" && $method != "" && $roll == "All" && $case == 0)
{
	$sql = "SELECT * FROM dashboard_data";
	$result = mysql_query($sql,$con);
	if($result)
	{
		 while($row = mysql_fetch_assoc($result))
                 {
                 	array_push($data,$row);
                 }		
		echo json_encode($data);
		
	}
	else
	{
		$data['error'] = mysql_error(); 
		echo json_encode($data);
	}
}

if($col)
{	
	if($roll == "1a")
	{	
		$sql = "SELECT  $col,roll_no FROM dashboard_data";
	}
	else
	{
		$sql = "SELECT  $col ,roll_no  FROM dashboard_data where roll_no = $roll";
	}
	$result = mysql_query($sql,$con);
	if($result)
	{
		while($row = mysql_fetch_assoc($result))
		{
			array_push($data,$row);	
		}
			
	}	
	echo json_encode($data);
}

if($case == 1)
{
	if($roll == "All")
	{
		$sql = "SELECT * FROM dashboard_data";
	}
	else
	{
		$sql = "SELECT * FROM dashboard_data where roll_no=$roll";
	}
	$result = mysql_query($sql,$con);
        if($result)
        {
                 while($row = mysql_fetch_assoc($result))
                 {
                        array_push($data,$row);
                 }
                echo json_encode($data);

        }
        else
        {
                $data['error'] = mysql_error();
                echo json_encode($data);
        }
}

mysql_close($con);
?>
