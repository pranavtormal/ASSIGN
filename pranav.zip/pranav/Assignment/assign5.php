<!DOCTYPE html>
<?php
session_start();
//:w
//$ses_id = ///"17d21e44e647f1d0659ebe3f4c36e53a";
$ses_id = session_id();
//echo "$ses_id";
//$_SESSION['id'] = $ses_id;
exec("/opt/MicroWorld/sbin/runasroot /bin/mkdir -p '/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id'");
exec("/opt/MicroWorld/sbin/runasroot /bin/chmod -R 777 '/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id'");
copy("/opt/MicroWorld/var/www/htdocs/pranav/default_policy/abc_w.ini","/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id/abc_w.ini");

function ini_read($ses_id)

{
        $file=fopen("/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id/abc_w.ini","r");
	//$file = fopen("abc_w.ini","r");
        $arr=array();
        if($file)
        {
                while(!feof($file))
                {
                        $data=trim(fgets($file));
                        if(strpos($data,"[")=== 0)
                        {
                                $section=trim($data,"[");
                                $sec=trim(str_replace("]",'',$section));
                                $arr[$sec]=array();
                        }
                        else
                        {       if($data !="")
                                {
                                $raw=explode("=",$data);
                                $key=trim($raw[0]);
                                $value=trim($raw[1]);
                                $val=trim(str_replace('"','',$value));
                                $arr[$sec][$key]=trim($val);
                                }
                        }
                }
        fclose($file);
        return $arr;
        }
        else
        {

                echo "File not Found.";
        }
}
$a=ini_read($ses_id);
//print_r($a);

if($_POST['save'])
{

	$policy = trim($_POST['policy']);
	$arr[WIN][FILEAV] = $_POST['fileav']?"1":"0";
	$arr[WIN][WEBPRO] = $_POST['webpro']?"1":"0";
	$arr[WIN][FIREWALL] = $_POST['firewall']?"1":"0";
	$arr[WIN][ODSSCHEDULE] = $_POST['ods_schedule']?"1":"0";
	$arr[WIN][MWLI] = $_POST['mwli']?"1":"0";
	$arr[WIN][MWLE] = $_POST['mwle']?"1":"0";
	$arr[LINUX][LINUXFILEAV]  = $_POST['lfile_av']?"1":"0";
	$arr[LINUX][LINUXODS] = $_POST['linuxods']?"1":"0";
	$arr[LINUX][LINUXSCHEDULE] = $_POST['lschedule']?"1":"0";
	$arr[LINUX][LINUXSCHEDULEUPDATE] = $_POST['lschedule_update']?"1":"0";
	exec("/opt/MicroWorld/sbin/runasroot /bin/mkdir -p '/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy'");
	exec("/opt/MicroWorld/sbin/runasroot /bin/chmod -R 777 '/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy'");
	function ini_write($arr,$ses_id)

	{  //	echo $ses_id=$_SESSION['id'];
	
        	if($arr)
        	{
                	$file=fopen("/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id/abc_w.ini","w+");
                	$delim = '"';
                	if($file)
                	{
                        	$sec_arr=array_keys($arr);
                        	foreach($sec_arr as $sec)
                        	{
                                	$sec_arr_keys = array_keys($arr[$sec]);
                                	fwrite($file,"[$sec]\n");
                                	foreach($sec_arr_keys as $val)
                                	{
						$val;
                                        	$data = $arr[$sec][$val];
                                        	fwrite($file,"$val=$delim$data$delim\n");

                                	}
                      		}

                	fclose($file);
			}

                	else
                	{
                        	echo "Error in writing File";
                	}
			
        	}
	}
	ini_write($arr,$ses_id);

	//To check white-space for given path
	//echo "/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id/abc_w.ini";
	//echo "<br/>";
	//echo "/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy/abc_w.ini";
	copy("/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id/abc_w.ini","/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy/abc_w.ini");
}
if($_POST['submit'])
{
        $arr[WIN][FILEAV] = $_POST['fileav']?"1":"0";
        $arr[WIN][WEBPRO] = $_POST['webpro']?"1":"0";
        $arr[WIN][FIREWALL] = $_POST['firewall']?"1":"0";
        $arr[WIN][ODSSCHEDULE] = $_POST['ods_schedule']?"1":"0";
        $arr[WIN][MWLI] = $_POST['mwli']?"1":"0";
        $arr[WIN][MWLE] = $_POST['mwle']?"1":"0";
        $arr[LINUX][LINUXFILEAV]  = $_POST['lfile_av']?"1":"0";
        $arr[LINUX][LINUXODS] = $_POST['linuxods']?"1":"0";
        $arr[LINUX][LINUXSCHEDULE] = $_POST['lschedule']?"1":"0";
        $arr[LINUX][LINUXSCHEDULEUPDATE] = $_POST['lschedule_update']?"1":"0";
	$policy = $_POST['upolicy'];
        function ini_write($arr,$policy)

        {

                if($arr)
                {
                        $file=fopen("/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy/abc_w.ini","w+");
                        $delim = '"';
                        if($file)
                        {
                                $sec_arr=array_keys($arr);
                                foreach($sec_arr as $sec)
                                {
                                        $sec_arr_keys = array_keys($arr[$sec]);
                                        fwrite($file,"[$sec]\n");
                                        foreach($sec_arr_keys as $val)
                                        {
                                                $val;
                                                $data = $arr[$sec][$val];
						 fwrite($file,"$val=$delim$data$delim\n");

                                        }
                                }

                        fclose($file);

                        }

                        else
                        {
                                echo "Error in writing File";
                        }
                }
        }
        ini_write($arr,$policy);
}
//session_destroy();
?>
<html>
<head>
	<title>Policy</title>
	<style>
		 tr:nth-child(odd) {background: #E5FFCC} 
		 tr:nth-child(even) {background: #CCCCFF}
	
		.modal{
			display:none;
			position:fixed;
			z-index:1;
			padding-top:100px;
			left:0;
			top:0;
			width:100%;
			height:100%;
			overflow:auto;
			background-color: rgb(0,0,0);
			background-color: rgba(0,0,0,0.4);
		      }
		.modal-content
		     {
			background-color:#fefefe;
			margin:auto;
			padding:10px;
			border:1px solid #888;
			width:70%;
		     }
		.close 
		     {
    			color: red;
    			float: right;
    			font-size: 28px;
    			font-weight: bold;
		     }
		.close:hover,
		.close:focus 
		    {
    			text-decoration: none;
    			cursor: pointer;

		    }
			 	
	</style>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script>
		function dmodal()
		{
			document.getElementById('modal').style.display = "block";
			var val = "";
                        if ($('.check').is(':checked'))
                        {
                        	var checkbox = document.getElementsByClassName('check');
                        	for(var i=0;checkbox[i];i++)
                                	{
                                                if(checkbox[i].checked)
                                                {
                                                        val= checkbox[i].value;
                                                }
                                        }
			}
			$.ajax({
				type:'post',
				url:'assign5a.php',
				data:{"puser":val},
				success:function(data){
					//alert(data);
					$('#modal-content').html(data);
				
				}
			});
				
		}
		function closeModal()
		{
			document.getElementById('modal').style.display="none";
		}

		$(document).ready(function()
		{
			$('.check').click(function () 
			{
  		  		//check if checkbox is checked
    				if ($('.check').is(':checked'))
				{
        				$('#update').removeAttr('disabled'); //enable update button
					$('#update').css('background-color','green');
        
    				} 
				else 
    				{
        				$('#update').attr('disabled', true); //disable button
					$('#update').css('background-color','white');

    				}
			});
			//open popup window
			/*$('.update').click(function()
			{
				var value = "";
				 if ($('.check').is(':checked'))
                                 {
                                        var checkbox = document.getElementsByClassName('check');
					for(var i=0;checkbox[i];i++)
					{
						if(checkbox[i].checked)
						{
							value= checkbox[i].value;
						}
					}
				
                                        window.open("assign5a.php?puser="+value,"","width=550,height=450");
                                }

			});
			*/

		});

	</script>	
</head>
<body><center>
<table width="100%" id="outer" height="300px" border="1">
	<tr>
	<td><form method="post">
		Policy :<input type="text" name="policy" id="policy" autocomplete="off"/> <br/><br/>
		<fieldset>
			<legend>WIN</legend>
		<table style="white-space:nowrap;">
			<tr>

				<td width="200px">
				<input type="checkbox" name="fileav"
				<?php
					if($a["WIN"]["FILEAV"] == 1)
					{
						echo "checked";
					}
				?>
				/> FILEAV 
				</td>
				<td>
				<input type="checkbox" name="webpro"
				<?php
					if($a["WIN"]["WEBPRO"] == 1)
					{
						echo "checked";
					}
				?>
				/>WEBPROTECTION
				</td>
			</tr>
			<tr style="background:none">
                                <td width="200px"> 
				<input type="checkbox" name="firewall";
				<?php
					if($a["WIN"]["FIREWALL"] == 1)
					{
						echo "checked";
					}
				?>
				/> FIREWALL 
				</td>
                                <td> 
				<input type="checkbox" name="ods_schedule"
				<?php
					if($a["WIN"]["ODSSCHEDULE"] == 1)
					{
						echo "checked";
					}
				?>	
				/> ODSSCHEDULE 
				</td>
                        </tr>
			<tr>
                                <td width="200px"> 
				<input type="checkbox" name="mwli"
				<?php
					if($a["WIN"]["MWLI"] == 1) 
					{
						echo "checked";
					}
				?>
				/> MWLI 
				</td>
                                <td> 
				<input type="checkbox" name="mwle"
				<?php
					if($a["WIN"]["MWLE"] == 1)
					{
						echo "checked";
					}
				?>
				/> MWLE 
				</td>
                        </tr>
					
		</table>
		</fieldset>
		<fieldset>
			<legend>LINUX</legend>			
		<table style="white-space:nowrap;">
                          <tr>
                          	<td width="200px"> 
				<input type="checkbox" name="lfile_av"
				 <?php
                                        if($a["LINUX"]["LINUXFILEAV"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
				/> LINUXFILEAV 
				</td>
                                <td> 
				<input type="checkbox" name="linuxods"
				 <?php
                                        if($a["LINUX"]["LINUXODS"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
				/> LINUXODS 
				</td>
                          </tr>
                          <tr style="background:none">
                                <td width="200px"> 
				<input type="checkbox" name="lschedule"
				 <?php
                                        if($a["LINUX"]["LINUXSCHEDULE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
				/> LINUXSCHEDULE 
				</td>
                                <td> <input type="checkbox" name="lschedule_update"
				 <?php
                                        if($a["LINUX"]["LINUXSCHEDULEUPDATE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
				/> LINUXSCHEDULEUPDATE 
				</td>
                          </tr>
                 </table>
		</fieldset>
		<table>
			<tr>
				<td> <input type="submit" value="Save" name="save" style="background-color:green"/><td>
			</tr>
		</table>
		</form>
		</td>
		</tr>
	</table>	
	</center>
	<p><input type="button" value="Update" id="update" onclick="dmodal()" disabled/></p>
	<div id="modal" class="modal">
		<div id="modal-content" class="modal-content">
		
		</div>
	</div>
	<div style="height:235px; border:1px solid grey;overflow:auto">
	<table width="100%" height="235px" border="1" style="white-space:nowrap">
		<tr>
		<td>	
		<table width="100%" style="overflow:auto" id="upolicy">
		<tr>
			<td><center><font color="green"><b>User Policy<b></font></center></td>
		</tr>
		
		
		<?php
			$path = "/opt/MicroWorld/var/www/htdocs/pranav/user_policy/";
			$files = scandir($path);
			//print_r($files);
			foreach($files as $dir)

			{	if($dir != "." && $dir != "..")
				{
					echo"<tr class=\"upolicy\"><td><input type=\"checkbox\" value=\"$dir\" class=\"check\"/>$dir</td></tr>";	
				}
			}
		?>
		
	
		</table>
		</td>
		</tr>
	</table>
	</div>
</body>
</html>
