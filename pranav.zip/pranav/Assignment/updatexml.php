<!DOCTYPE html>
<html>
<head>
	<title>Update XML</title>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
	<script src="jquery-1.7.1.min.js" ></script>
	<script>

		$(document).ready(function(){
			$.ajax({
				type:'post',
				url:'xml_operation.php',
				data:{'case':'readrule'},
				success:function(resp){
					$('#ruleDiv').html(resp);
				}
			});
			
			$(".check").click(function(){
				alert("hjfdkj");
				if($(".check").is(":checked"))
				{
					$("#btnup").removeAttr("disabled");
					
				}
				else
				{
					$("#btnup").attr("disabled",true);
				}
			});
		});
	
		function upShift()
		{	

			var val = "";
                        if ($('.check').is(':checked'))
                        {
                                var checkbox = document.getElementsByClassName('check');
                                for(var i=0;checkbox[i];i++)
                                        {
                                                if(checkbox[i].checked)
                                                {
                                                        val= checkbox[i].value;
                                                }
                                        }
                       			var btn = $('#btnup').val();
					
                        		//alert(btnup); 
			//alert(val);
				$.ajax({
					type:'post',
					url:'xml_operation.php',
					data:{'rule_name':val,'option':btn},
					success:function(resp){
						$("#ruleDiv").html(resp);
					}
				});

			}
		}
		function downShift()
                {

                        var val = "";
                        if ($('.check').is(':checked'))
                        {
                                var checkbox = document.getElementsByClassName('check');
                                for(var i=0;checkbox[i];i++)
                                        {
                                                if(checkbox[i].checked)
                                                {
                                                        val= checkbox[i].value;
                                                }
                                        }
                                        var btn = $('#btndown').val();

                                        //alert(btnup);
                        //alert(val);
                                $.ajax({
                                        type:'post',
                                        url:'xml_operation.php',
                                        data:{'rule_name':val,'option':btn},
                                        success:function(resp){
                                                $("#ruleDiv").html(resp);
                                        }
                                });

                        }
                }

	</script>
</head>
<body>
	<fieldset>
	<legend align="center"><b><font color="green">Update XML</font></b></legend>
	<form action="" method="post">
		<table>
			<tr>
				<td>Enter name Attribute of rule Tag:</td>
				<td><input type="text" name="rule" id="rule" autocomplete="off"/></td>
			</tr>
			<tr>
				<td><input type="checkbox" name="sport" id="sport" value="ip-source-port"/>Add IP Source Port</td>
			</tr>
			<tr>
                                <td><input type="checkbox" name="icmp" id="icmp" value="process-icmp"/>Update Icmp-redirectI</td>
                        </tr>
			 <tr>
                                <td><input type="checkbox" name="icmpv6" id="icmpv6" value="process-icmpv6"/>Update Icmpv6-packet-bigO</td>
                        </tr>
			 <tr>
                                <td><input type="submit" value="Submit"/></td>
                        </tr>
		</table>	
	</form>
	</fieldset>
	<fieldset>
	<legend align='center'>Rule Name</legend>
	<div id="ruleDiv" style="height:380px;overflow:auto;">
	</div>
	<input type="button" name ="up" id ="btnup" value ="ShiftUp" onclick="upShift()"/>
	<input type="button" name ="down" id="btndown" value ="ShiftDown" onclick="downShift()"/>
	
	</fieldset>
</body>
</html>
<?php
$xml = simplexml_load_file("firewall-rules.xml");
if($_POST)
{
	$name = trim($_POST['rule']);
	$sport = trim($_POST['sport']);
	$icmp = trim($_POST['icmp']);
	$icmpv = trim($_POST['icmpv6']);
	//$xml = simplexml_load_file("firewall-rules.xml");
	//$dom = new DOMDocument();
	//$dom->preserveWhitespace = False;
	//$dom->formatOutput = True;
	//$dom->loadXML($sxml->asXML()); 
	//$xml = new SimpleXMLElement($doml->saveXML());
	
	/*
	$dom = dom_import_simplexml($xml)->ownerDocument;
	$dom->formatOutput = True;
	$dom->preserveWhitespace = False;
	*/
	//print_r($xml);
	//echo $xml->getName();
	//$dom = dom_import_simplexml($xml);
	foreach($xml->children() as $rule)
	{
		$arr = $rule->attributes();
		//print_r($attr);
		$attr = $arr['name'];
		if($attr == $name)
		{
			foreach($rule->children() as $process)
			{
				$tag = $process->getName();
				if($tag != "")
				{	
					if($tag == $sport)
					{
						$process->addChild("port","100");
					}
				 	if($tag == $icmp)
                                	{
                                        	$process->redirectI = "True";
                                	}
				 	if($tag == $icmpv)
                                	{
                                        	$process->{'packet-bigO'} = "True";
                                	}
				}
			}
		}
		
	}
	$dom = new DOMDocument();
        $dom->preserveWhiteSpace = False;
        $dom->formatOutput = True;
        $dom->loadXML($xml->asXML());	
$dom->save("firewall-rules.xml");	
}
?>
