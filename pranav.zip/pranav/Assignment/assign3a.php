<?php
	//$file=fopen("L0escanset.ini","r");
	$arr = parse_ini_file("abc.ini",true);
	print_r($arr);
	echo"<br>";

	/*while(!feof($file))
	{
	$data=fgets($file);
	echo$data;
	}
*/
?>
