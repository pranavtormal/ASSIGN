<script src="jquery-1.7.1.min.js"></script>
<script>
	/*
	function addnew()
	{
		var arr = [5,2,3,6,4,8,7];
		return arr;
	}
	//var abc = {callback:"addnew"};
	$(document).ready(function(){
		var abc = {callback_ASA:addnew};
		//abc.callback_ASA();
		//alert(abc.callbackASA);
	});
	
	
	var obj = {"key":'json',"val":addnew()};
	console.log(obj);
	console.log(obj.key);
	console.log(obj.val);
	alert(obj.val);
	var str = JSON.stringify(obj);
	//console.log(typeof(str));
	*/
	
	function  abc (){
		var arr = [7,8,14,4,7];
		
	}

	abc.prototype.testProperty = "prototype property";
	abc.prototype.key = "key property";
	abc.prototype.val = 888;
	abc.prototype.Model = "From model Property";
	var obj = new abc('hhh');
	console.log(obj.testProperty);
	console.log(obj.val);
	console.log(abc);

</script>
