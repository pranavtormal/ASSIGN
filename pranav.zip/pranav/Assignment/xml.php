<?php

$doc = new DOMDocument();
$doc->formatOutput = TRUE;
$doc->preserveWhiteSpace = FALSE;
$root = $doc->createElement("note");
$root = $doc->appendChild($root);

$mail = $doc->createElement("mail");
$mail = $root->appendChild($mail);
$mail->setAttribute("id",1);
$to = $doc->createElement("to");
$to = $mail->appendChild($to);
$text = $doc->createTextNode("Kiran");
$text = $to->appendChild($text);
$from = $doc->createElement("from");
$from = $mail->appendChild($from);
$text = $doc->createTextNode("Steve");
$text = $from->appendChild($text);
$head = $doc->createElement("heading");
$head = $mail->appendChild($head);
$text = $doc->createTextNode("Reminder");
$text = $head->appendChild($text);
$body = $doc->createElement("body");
$body = $mail->appendChild($body);
$text = $doc->createTextNode("there is no installation needed");
$text = $body->appendChild($text);

$mail = $doc->createElement("mail");
$mail = $root->appendChild($mail);
$mail->setAttribute("id",2);
$to = $doc->createElement("to");
$to = $mail->appendChild($to);
$text = $doc->createTextNode("Kiran");
$text = $to->appendChild($text);
$from = $doc->createElement("from");
$from = $mail->appendChild($from);
$text = $doc->createTextNode("Steve");
$text = $from->appendChild($text);
$head = $doc->createElement("heading");
$head = $mail->appendChild($head);
$text = $doc->createTextNode("Reminder");
$text = $head->appendChild($text);
$body = $doc->createElement("body");
$body = $mail->appendChild($body);
$text = $doc->createTextNode("there is no installation needed");
$text = $body->appendChild($text);


$doc->save("test.xml");
?>
