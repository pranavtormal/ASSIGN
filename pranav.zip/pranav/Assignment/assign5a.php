<?php
	echo "<span class=\"close\" onclick=\"closeModal()\">&times;</span>";

	echo "<center><b>";
	echo $policy = $_POST['puser'];
	echo "</b></center>";
	function ini_read($ses_id,$policy)

{
        //$file=fopen("/opt/MicroWorld/var/www/htdocs/pranav/Assignment/$ses_id/abc_w.ini","r");
        $file = fopen("/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy/abc_w.ini","r");
        $arr=array();
        if($file)
        {
                while(!feof($file))
                {
                        $data=trim(fgets($file));
                        if(strpos($data,"[")=== 0)
                        {
                                $section=trim($data,"[");
                                $sec=trim(str_replace("]",'',$section));
                                $arr[$sec]=array();
                        }
                        else
                        {       if($data !="")
                                {
                                $raw=explode("=",$data);
                                $key=trim($raw[0]);
                                $value=trim($raw[1]);
                                $val=trim(str_replace('"','',$value));
                                $arr[$sec][$key]=trim($val);
                                }
                        }
                }
        fclose($file);
        return $arr;
        }
        else
        {

                echo "File not Found.";
        }
}
$a=ini_read($ses_id,$policy);
//print_r($a);

if($_POST['submit'])
{
        $arr[WIN][FILEAV] = $_POST['fileav']?"1":"0";
        $arr[WIN][WEBPRO] = $_POST['webpro']?"1":"0";
        $arr[WIN][FIREWALL] = $_POST['firewall']?"1":"0";
        $arr[WIN][ODSSCHEDULE] = $_POST['ods_schedule']?"1":"0";
        $arr[WIN][MWLI] = $_POST['mwli']?"1":"0";
        $arr[WIN][MWLE] = $_POST['mwle']?"1":"0";
        $arr[LINUX][LINUXFILEAV]  = $_POST['lfile_av']?"1":"0";
        $arr[LINUX][LINUXODS] = $_POST['linuxods']?"1":"0";
        $arr[LINUX][LINUXSCHEDULE] = $_POST['lschedule']?"1":"0";
        $arr[LINUX][LINUXSCHEDULEUPDATE] = $_POST['lschedule_update']?"1":"0";
       
        function ini_write($arr,$policy)

        {  

                if($arr)
                {
                        $file=fopen("/opt/MicroWorld/var/www/htdocs/pranav/user_policy/$policy/abc_w.ini","w+");
                        $delim = '"';
                        if($file)
                        {
                                $sec_arr=array_keys($arr);
                                foreach($sec_arr as $sec)
                                {
                                        $sec_arr_keys = array_keys($arr[$sec]);
                                        fwrite($file,"[$sec]\n");
                                        foreach($sec_arr_keys as $val)
                                        {
                                                $val;
                                                $data = $arr[$sec][$val];
						fwrite($file,"$val=$delim$data$delim\n");

                                        }
                                }

                        fclose($file);
                        
                        }

                        else
                        {
                                echo "Error in writing File";
                        }
                }
        }
        ini_write($arr,$policy);
}
?>

<html>
<head>
</head>
<body><center>
<table width="100%" id="outer" height="300px" border="1">
        <tr>
        <td><form method="post">
          
                <fieldset>
                        <legend>WIN</legend>
                <table style="white-space:nowrap;">
                        <tr>

                                <td width="200px">
                                <input type="checkbox" name="fileav"
                                <?php
                                        if($a["WIN"]["FILEAV"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> FILEAV
                                </td>
                                <td>
                                <input type="checkbox" name="webpro"
                                <?php
                                        if($a["WIN"]["WEBPRO"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                />WEBPROTECTION
                                </td>
                        </tr>
			 <tr style="background:none">
                                <td width="200px">
                                <input type="checkbox" name="firewall";
                                <?php
                                        if($a["WIN"]["FIREWALL"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> FIREWALL
                                </td>
                                <td>
                                <input type="checkbox" name="ods_schedule"
                                <?php
                                        if($a["WIN"]["ODSSCHEDULE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> ODSSCHEDULE
                                </td>
                        </tr>
                        <tr>
                                <td width="200px">
                                <input type="checkbox" name="mwli"
                                <?php
                                        if($a["WIN"]["MWLI"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> MWLI
                                </td>
                                <td>
                                <input type="checkbox" name="mwle"
                                <?php
                                        if($a["WIN"]["MWLE"] == 1)
                                        {
					   echo "checked";
                                        }
                                ?>
                                /> MWLE
                                </td>
                        </tr>

                </table>
                </fieldset>
                <fieldset>
                        <legend>LINUX</legend>
                <table style="white-space:nowrap;">
                          <tr>
                                <td width="200px">
                                <input type="checkbox" name="lfile_av"
                                 <?php
                                        if($a["LINUX"]["LINUXFILEAV"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXFILEAV
                                </td>
                                <td>
                                <input type="checkbox" name="linuxods"
                                 <?php
                                        if($a["LINUX"]["LINUXODS"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXODS
                                </td>
                          </tr>
                          <tr style="background:none">
                                <td width="200px">
                                <input type="checkbox" name="lschedule"
                                 <?php
					  if($a["LINUX"]["LINUXSCHEDULE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXSCHEDULE
                                </td>
                                <td> <input type="checkbox" name="lschedule_update"
                                 <?php
                                        if($a["LINUX"]["LINUXSCHEDULEUPDATE"] == 1)
                                        {
                                                echo "checked";
                                        }
                                ?>
                                /> LINUXSCHEDULEUPDATE
                                </td>
                          </tr>
                 </table>
                </fieldset>
                <table>
                        <tr>
                                <td> 
					<input type="hidden" value="<?php echo $policy;?>" name="upolicy"/>
					<input type="submit" value="Save" name="submit" id="save"/>
				</td>
                        </tr>
                </table>
                </form>
                </td>
                </tr>
        </table>
        </center>
</body>
</html>
