<?php
class Student
{
	private $name;
	private $roll;
	
	function __construct($n,$m)
	{
		$this->name = $n;
		$this->roll = $m;
	} 
	function getName($d)
	{
		return $this->name;
	}
}

$std = new Student("Ketan",45);
$j=$std->getName();
echo "$j";
?>
