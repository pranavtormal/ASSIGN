<?php

function encrypt($inbuf)
{
	$i = 0;
	$seed0 = 0; //pointer
	$seed1 = 0;//pointer
	$a = 0; // pointers
	$b = 0;
	$c = 0;
	$d = 0;
	$ob = 0; // pointer to oputput
	$seed = rand(0,65535); // random number  btwn 0 to 65535 
	$newseed0 = 0;
	$newseed1 = 0;
	$temp = 0;
	$ob1 = array();
	$ob2 = array();
	$ob = $ob2;
	
	$seed0 = $seed & 0xFF;//255
	$temp = $seed >> 8; // right shift
	$seed1 = $temp & 0xFF; 
	if ($seed0 >=65 && $seed0 <= 90) // new seed values
	{
		$newseed0 = $seed0 + 26;
		
	}
	else
	{
		$newseed0 = $seed0;
	}

	if ($seed1 >= 65 && $seed1 <= 90)
	{
		$newseed1 = $seed1 + 26;
	} 
	else 
	{
		$newseed1 = $seed1;
	}

	if($inbuf != "")
	{
	
		$inbuf = trim($inbuf);
		$inbuf = chunk_split($inbuf,1,',');//spliting i/p to conv into array 
		$inbuf = explode(',',$inbuf); // conv str into array
		for($i=0;$i<count($inbuf)-1;$i++)
		{
			$c = $d = ord($inbuf[$i]); //get ascii of i/p
			$c = $c & 0x0F; //bitwise & 
			$d = $d & 0xF0;  
			$d = $d >> 4; 
			$d = $d & 0x0F;
			$ob1[$i*2] = $c + 65 ;   //ob1 & ob2 are array
			$ob1[($i*2)+1] = $d + 65;   
			
		}
		
		for ($i=0 ; $i < count($ob1); $i++) 
		{
			if ($i%2)
			{
				$ob1[$i] = $ob1[$i] ^ $newseed1; // odd characters	
			} 
			else 
			{
				$ob1[$i] = $ob1[$i] ^ $newseed0; //even characters
			}
		}
		//$ob is filled with values from 3rd position we use additional variable to define the position
		$j = 2;
		$c = 0 ;
		$d = 0 ; 
		for ($i=0 ; $i <count($ob1);$i++) 
		{
			$c = $d= $ob1[$i]; //ascii values in ob1
			$c = $c & 0x0F;
			$d = $d & 0xF0;
			$d = $d >> 4;
			$d = $d & 0x0F;
			$ob[$j] = chr($c + 65) ; //ascii to character
			$ob[$j+1] = chr($d + 65);
			$j = $j + 2;
		}

		$a = $b = $seed0; 
		$a = $a & 0x0F; //bitwise & with 15
		$a = $a + 65;
		$b = $b & 0xF0; //240
		$b = $b >> 4;
		$b = $b & 0x0F;
		$b = $b + 65;
	
		$ob[0] = chr($a); // ob is o/p array
		$ob[1] = chr($b);// seed values

		$a = $b = $seed1;
		$a = $a & 0x0F; //15
		$a = $a + 65;
		$b = $b & 0xF0; //240
		$b = $b >> 4;
		$b = $b & 0x0F;
		$b = $b + 65;
		$ob[count($ob)] = chr($a);//seed values at last
		$ob[count($ob)] = chr($b);
		ksort($ob); //sorting  array key wise			
		return join('',$ob); // array to string
	}
}

$t = encrypt("users123");
function decrypt($inbuf)
{
	$seed0 =0; // seed pointers
	$seed1 = 0;
	$a = 0;
	$b = 0;
	$c = 0;
	$d = 0;
	$newseed0 = 0 ;
	$newseed1 = 0 ;
	
	$inbuf = chunk_split($inbuf,1,','); //spliting i/p to conv into array
	$inbuf = explode(",",$inbuf);
	$len = count($inbuf); //array length
	$len= $len-1;
	
	if ($len % 2 == 1 )  // even only
	{ 
		return ;
	}
	
	for($i=0;$i<$len;$i++)
	{
		if (!($inbuf[$i] >= 'A' && $inbuf[$i] <= 'P'))
		{
			return ;
		}	
	}
	
	$a = ord($inbuf[0]) - 65; //ord i/p to ascii
	$b = (ord($inbuf[1]) -65) << 4; // left shift 4 bits
	$b = $b & 0xF0;
	$seed0 = $a + $b ;
	$a = ord($inbuf[$len-2]) - 65;
	$b = (ord($inbuf[$len-1]) - 65) <<4;
	$b = $b & 0xF0;
	$seed1 = $a + $b ;
	
	if ($seed0 >= 65 && $seed0 <= 90) 
	{
		$newseed0 = $seed0 + 26;
	} 
	else 
	{
		$newseed0 = $seed0;
	}

	if ($seed1 >= 65 && $seed1 <= 90) 
	{
		$newseed1 = $seed1 + 26;
	} 
	else 
	{
		$newseed1 = $seed1;
	}
	$outbuf1 = 0;
	$outbuf2 = array();
	$outbuf3 = array();
	$outbuf1 = array_slice($inbuf,2,-3); //remove 1st two and last two seed 
	$len = count($outbuf1);
	for($i = 0; $i < $len/2; $i++)
	{
		$c = 0 ;
		$d = 0 ;
		$c = ord($outbuf1[$i*2]) - 65; // conv to ascii value
		$d = (ord($outbuf1[($i*2)+1]) -65)<<4;
		$d = $d & 0xF0 ;
		$outbuf2[$i] = $c + $d;
	}
	for ($i=0;$i <count($outbuf2);$i++)
	{
		if ($i%2)
		{
			$outbuf2[$i] = $outbuf2[$i] ^ $newseed1; //odd characters
		} 
		else 
		{
			$outbuf2[$i] = $outbuf2[$i] ^ $newseed0; // even characters
		}
	}
	$len = count($outbuf2);

	for($i = 0; $i < $len/2; $i++)
	{
		$c = 0;
		$d = 0;
		$c =  $outbuf2[$i*2] - 65;
		$d = ($outbuf2[$i*2+1] - 65)<<4 ;
		$d = $d & 0xF0;
		$outbuf3[$i] = chr($c + $d);  // outbuf3 o/p array 		
	}
	return join('',$outbuf3); //conv array to string
}

$o = decrypt("$t");
//echo "$o";

Global $enc_alph; // asccessing into multiple functions
Global $enc_numr;
function ascii($a)
{
        return ord($a); //conv i/p to ascii
}

function char($r)
{
        return chr($r); //ascii to i/p
}
$enc_alph = "qilcpfuwryvajnxgetzhmsbdok"; 
$enc_alph = chunk_split($enc_alph,1,',');
$enc_alph = explode(",",$enc_alph);//string to array
$enc_alph = array_map("ascii",$enc_alph); //get ascii of each element into array
$enc_numr = "6810247593";
$enc_numr = chunk_split($enc_numr,1,',');
$enc_numr = explode(",",$enc_numr);
$enc_numr = array_map("ascii",$enc_numr);

function RotnEncrypt($input)
{	
	global $enc_alph;//array of ascii values a-z
        global $enc_numr;//array of ascii values 0 to 9
	$Input = chunk_split($input,1,',');
	$Input = explode(',',$Input); //conv string to array
	$Input = array_map('ascii',$Input);//here ascii is function gives array of ascii values  
	$InputLength = count($Input) - 1;
	$Output =array();
	$SeedIndx; //pointer to seed
	$i=0;$j=0;
	if($InputLength > 0) 
	{
		if(($InputLength % 2) === 0) //even length
		{
			$SeedIndx = $InputLength / 2;
		}
		else
		{
			$SeedIndx = (floor($InputLength / 2)) + 1; //odd length
		}
		$rand_no = rand(0,25); // random num btwn 0 to 25
		$rand_alph = $rand_no;
		$rand_numr = $rand_alph % 10; // 0 to 9
		$InputcharCode;
		for ($i = 0,$j = 0; $i < $InputLength; $i++,$j++) 
		{

			$InputcharCode = $Input[$i];
			if ($InputcharCode >= 65 && $InputcharCode <= 90) 
			{
				$a = $Input[$i];
				
			} 
			else 
			{
				$a = $Input[$i];
			
			}
			if ($a >= 97 && $a <= 122 ) //a-z
			{
				$Tmp = $a - 97 + $rand_alph; 
				if ($Tmp < 26)
				{
					$Indx = $Tmp;
				}
				else
				{
					$Indx = $Tmp % 26;
				}

				$Output[$j] = $enc_alph[$Indx];// $Output- o/p array
			}
			else if ($a >= 48 && $a <= 57) //0-9
			{
				$Tmp = $a - 48 + $rand_numr;
				if ($Tmp < 10)
				{	$Indx = $Tmp;
				}
				else
				{
					$Indx = $Tmp % 10;
				}
				$Output[$j] = $enc_numr[$Indx];
			} 
			else if ($a >= 65 && $a <= 90) //A-Z
			{
				$Tmp = $a - 65 + $rand_alph;
				if ($Tmp < 26)
				{
					$Indx = $Tmp;
				}
				else
				{
				$Indx = $Tmp % 26;
				}
				$Output[$j] = $enc_alph[$Indx]-32;
			}
			else 
			{
				$Output[$j] = $a;
			}
		}//end of for loop 
		$add =  $rand_alph + 97; // seed character to add 
		array_splice($Output,$SeedIndx,0,$add);// insert seed character.
		$Output = array_map("char",$Output); //ascii to character or int etc.
		return join('',$Output);// conv array to string		
	}
	else
	{
		return -1;
	}
}

$out = RotnEncrypt("Login here");
echo "$out";
echo"<br/>";

function RotnDecrypt($input)
{
	global $enc_alph;  //array of ascii values a-z 
        global $enc_numr;  //array of ascii values 0-9
	$Input = chunk_split($input,1,',');
	$Input = explode(',',$Input);  //conv i/p string to array 
	$Input = array_map("ascii",$Input); // ascii values of i/p
	$InputLength = count($Input) - 1;
	$Output = array();
	$SeedIndx;
	$alph = array();
	$numr = array();
	$i = 0; $j = 0;			
	if($InputLength > 0)
	{
		if ((($InputLength - 1 ) % 2) === 0) //even lenght
		{
			$SeedIndx = ($InputLength - 1 )/ 2;
		}
		else
		{
			$SeedIndx = floor(( $InputLength - 1 ) / 2) + 1;
		}			
	}
	$rand_alph = $Input[$SeedIndx] - 97;// seed character
	$rand_numr = $rand_alph % 10;   //0-9
	
	for ($i = 0; $i < 26; $i++) //for charaters
	{
		$Tmp = $i + $rand_alph;
		if ($Tmp < 26)
		{
			$Indx = $Tmp;
		}
		else
		{
			$Indx = $Tmp % 26;
		}

		$Indx = $enc_alph[$Indx] - 97;
		$alph[$Indx] = 97 + $i; // ascii value
	}
	//$alph and $numr are array
	for ($i = 0; $i < 10; $i++)  //for 0-9
	{
		$Tmp = $i + $rand_numr;
		if ($Tmp < 10)
		{
			$Indx = $Tmp;
		}
		else
		{
			$Indx = $Tmp % 10;
		}
		$Indx = $enc_numr[$Indx] - 48;
		$numr[$Indx] = 48 + $i; //ascii value
	}

	for ($i = 0; $i < $InputLength; $i++,$j++)
	{
		if ($i === $SeedIndx) //check seed & skip
		{
			$i++;
		}
		$InputcharCode = $Input[$i];
		if ($InputcharCode >= 65 && $InputcharCode <= 90) 
		{
			$a = $InputcharCode ;
		}
		else 
		{
			$a = $InputcharCode ;
		}
		if ($a >= 97 && $a <= 122)  // a-z 
		{
			$Output[$j] = $alph[$a - 97]; // o/p array 
		}
		else if ($a >= 48 && $a <= 57)  //0-9
		{
			$Output[$j] = $numr[$a - 48];
		}
		else if($a >= 65 && $a <= 90) //A-Z
		{
			if( ($alph[$a- 65]-32) < 0)
			{
				return -1;
			}
			else
			{
				$Output[$j] = $alph[$a-65] - 32;
			}	
		}
		else
		{
			$Output[$j] = $a;
		}
	}//end of for loop
	$Output = array_map("char",$Output); //ascii to characters or int etc...
	array_splice($Output,$SeedIndx,1);  // remove seed 
	return join('',$Output);  // conv array to string 			
}
//$rtn = RotnDecrypt("zueoxi");
//echo "$rtn";
?>

