<?php
class Db
{
	private $host = "localhost"; //server name
	private $user = "root";      //user name
	private $password = "root123"; // password
	private $database = "studentdb"; // database name
	private $con = "";  
	private $arr = array();

	function __construct()
	{
		$this->makeConn();
	}
	public function makeConn()
	{
		if($this->con == "")
		{
			$this->con = mysql_connect($this->host,$this->user,$this->password);
			if($this->con)
			{
				mysql_select_db($this->database,$this->con);
				
			}
			else
			{
				return $arr['msg'] = "Failed to connect";
			}
		}
	}
	public function makeQuery($sql)      //Query execution function 
	{
		$result = mysql_query($sql,$this->con);
		$data = array();
		$qry_array = array();
		$sql = strtolower(trim($sql));    
		$qry_array  = explode(" ",$sql); // Exploding Query query to indentify operation
		//print_r($qry_array);
		
		if($result)
		{
			if($qry_array[0] == "select")
			{
				while($row = mysql_fetch_assoc($result))
				{
					array_push($data,$row);
				}
				if(count($data) != 0 && $data != null)
				{
					return $data;
				}
				else
				{
					return $data['msg'] = "No record found";
				}
			}
			elseif($qry_array[0] = "update" || $qry_array[0] = "insert")
			{
				if($result)
				{
					return true;
				}
				else
				{
					return "query error";
				}
			}
			elseif($qry_array[0] = "delete")
			{
				if($result)
				{
					return true;
				}
				else
				{
					return "query error";
				}
			}
	
		}
		else
		{
			return $arr['msg'] = "Query Failed";
		}
	}
	public function closeConnection()
	{
		if($this->con)
		{
			mysql_close($this->con);
		}
	}
	
}

?>
