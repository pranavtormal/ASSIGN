<?php
include_once("dbconn.php");
class Apicall extends Db
{

	public function insertData($roll,$name,$city)
	{
		$sql="INSERT INTO student_data VALUES ('$roll','$name','$city')";
		$res = $this->makeQuery($sql); 
		return $res;
	}
	public function deleteData($r)
	{
		if(!empty($r))
		{
			$sql = "DELETE FROM student_data WHERE roll_no=$r";
			$res = $this->makeQuery($sql);
			return $res;
		}
		else
		{
			return "Roll no not valid";
		}
		
	}
	public function getData($r,$n)  //data fetching function r=roll  no,n=name
	{
		
		if($r != "" && ($n == "" || $n == null))
		{
			$sql = "SELECT * FROM student_data WHERE roll_no='$r'";
		}
		elseif($n != "" && ($r == "" || $n == null))
		{
			$sql = "SELECT * FROM student_data WHERE name='$n'";
		}
		elseif($r != "" && $n != "")
		{
			$sql = "SELECT * FROM student_data WHERE roll_no='$r' OR name='$n'";
		}
		else
		{
			 $sql = "SELECT * FROM student_data";
		}
		$res = $this->makeQuery($sql);
		return $res;
	}
	public function updateData($roll,$name,$city)
	{	
		if(!empty($roll) && !empty($name) && !empty($city))
		{
			$sql = "UPDATE student_data SET name='$name',city='$city' WHERE roll_no='$roll'";
			$res = $this->makeQuery($sql);
			return $res;
		}
	
	}
}
?>
