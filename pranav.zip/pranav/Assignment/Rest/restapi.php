<?php

include_once("api.php");
header("Content-type:application/json");  //header data format
$obj = new Apicall();
$method = $_SERVER['REQUEST_METHOD'];
//echo "$method";

if(!empty($method))
{
	if($method == 'GET')
	{	
		$path = trim($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']); // url path
		$url = parse_url($path); 
		//print_r($url);
		$u = $url['query']; //Fetching only paramerters 
		parse_str($u);   //parse url parameters
		//echo "$r";
		$r = filter_var(trim($r),FILTER_SANITIZE_NUMBER_INT); // r = roll_no
		$n = filter_var(trim($n),FILTER_SANITIZE_STRING);    // n = name;
		$c = filter_var(trim($c),FILTER_SANITIZE_STRING);   //c = city
		//echo "$roll";
	}
	if($method == 'POST')
	{
		$data = file_get_contents("php://input"); //fetch body request data
		//var_dump($data);
		$data = json_decode($data,true);  // convert it into asscociative array
		//print_r($data);
		//$head = getallheaders(); //get ALL the Headers
		//print_r($head);
		if($data)
		{
			$r = $data['r'];
			$n = $data['n'];
			$c = $data['c'];
		}
		else
		{
			echo json_encode("not valid data");
			exit();
		}
	}
	if($method == 'PUT')
	{
		$data = file_get_contents("php://input");
		//print_r($data);
		$data = json_decode($data,true);
		//print_r($data);
		//$head = getallheaders();
		//print_r($head);
		if($data)
		{
			$r = $data['r'];
                        $n = $data['n'];
                        $c = $data['c'];
			if(empty($r) || empty($n) || empty($c))
			{
				echo json_encode("not valid data");
				exit();
			}
		}
		else
		{
			echo json_encode("not valid data");
			exit();
                        
		}
	
	}
		
	if(!empty($r) || !empty($n)  || !empty($c) )
	{
        	$roll = $r;
        	$name = $n;
		$city = $c;

		
		switch($method)
		{
			case 'GET':
				$data = $obj->getData($roll,$name);
				echo json_encode($data);
				break;
			case 'POST':
				//$data = $obj->insertData($roll,$name,$city);
				$data = $obj->getData($roll,$name,$city);
				echo json_encode($data);
				break;
			case 'PUT':
				$data = $obj->updateData($roll,$name,$city);
				if($data)
				{
					echo json_encode($data);
				}
				break;
			case 'DELETE':
				$data = $obj->deleteData($roll);
				echo json_encode($data);
				break;
		}
	}
	else
	{
		 echo json_encode("data not valid");
	}
}

$obj->closeConnection();

?>
