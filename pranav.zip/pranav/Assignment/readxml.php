<?php


function readxml()
{
$xml = simplexml_load_file("firewall-rules.xml") or die("Error");
//print_r($xml);
//$length_of_xml = count($xml);
//echo "length_of_xml:$length_of_xml";
foreach($xml->children() as $rule)
{       
	echo "Attribute Of rule:<br>";
	foreach($rule->attributes() as $attr => $val)
	{
	
		echo "$attr:$val<br>";
	}

	foreach($rule->children() as $process)
	{     
		$node = $process->getName();
		if($node != "")
		{	
			if($node == "ip-source-port" || $node == "ip-destination-port")
                	{
                        	echo "Attribute of $node:<br>";
                        	foreach($process->attributes() as $attr => $val)
                        	{
                                	echo "$attr: $val<br>";
                        	}

                        	$port = $process->children();
                        	if($port != "")
                        	{       
					echo "ip-source-port<br>";
                                	for($k = 0;$k < count($port);$k++)
                                	{
                                        	echo $port[$k]."<br>";
                                	}

                        	}
                	}
			else
			{
				echo "Attribute of $node:<br>";
				foreach($process->attributes() as $attr => $val)
				{
					echo "$attr: $val<br>";
				}
			}
		}
		/*
		if($node == "ip-destination-address")
		{
			echo "Attribute of ip-destination-address:<br>";
                        foreach($process->attributes() as $attr => $val)
                        {
                                echo "$attr: $val<br>";
                        }

		}
		
		if($node == "ip-source-port" || $node == "ip-destination-port")
		{
			echo "Attribute of ip-source-port:<br>";
                        foreach($process->attributes() as $attr => $val)
                        {
                                echo "$attr: $val<br>";
                        }

			$port = $process->children();
			if($port != "")
			{	echo "ip-source-port<br>";
				for($k = 0;$k < count($port);$k++)
				{
					echo $port[$k]."<br>";
				}

			}
		}
		/*
		if($node == "ip-destination-port")
		{
			echo "Attribute of ip-destination-port:<br>";
                        foreach($process->attributes() as $attr => $val)
                        {
                                echo "$attr: $val<br>";
                        }

			$port = $process->children();
			if($port != "")
			{
				//echo count($port);
				//echo "<br>";
				echo "ip-destination-port<br>";
				for($j = 0;$j < count($port);$j++)
				{
					echo $port[$j]."<br>";
				}
			}	
		}*/
		if($node == "process-icmpv6" || $node == "process-icmp")
		{
			$tag = $process->children();
			print_r($tag);
			foreach($tag as $key => $val)
			{
				echo "$key:$val.<br/>";
			}
			
		}
	} 
}
}
readxml();
//$replyI = $xml->rule[0]->{'process-icmp'}->{'echo-replyI'} = "True";
//$xml->asXML("firewall-rules.xml");
?>
