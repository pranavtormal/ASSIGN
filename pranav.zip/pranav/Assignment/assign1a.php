<!DOCTYPE html>
<html>
<head>
	<title>Student Information</title>
	<script>
	function validator()
	{
		var a=document.getElementById('name').value;
		//alert(a);
		if(a==null || a=="")
		{
			alert("Enter Name");
			return false;
		}

		var b=document.getElementById('rno').value;
		if(b==null || b=="")
		{
			alert("Enter Roll No");
			return false;
		} 

		var c=document.getElementById('contact').value;
		if(c==null || c=="")
		{
			alert("Enter Contact No");
			return false;
		}
		if(c.length<10)
		{
			alert("Enter 10 Digits Contact No");
		
                        document.getElementById('contact').value="";
			return false;
		}

	}
	function checkName(name)
	{
		//alert("hi");
		var letters = /^[A-Za-z\s]+$/;
		if(!name.match(letters))
		{
			alert("Enter only Characters");
			document.getElementById('name').value="";
		}

		if(name.length>=21)
		{
			alert("Enter less than 20 Characters");
                       document.getElementById('name').value="";
		}
	} 
	function checkRoll(roll)
	{
		//alert("hi");
		var digits = /^[0-9]+$/;
		if(!roll.match(digits))
		{
			alert("Enter only digits");
			document.getElementById('rno').value="";
		}

		if(roll.length>4)
		{
			alert("Enter less than 4 Digits");
			document.getElementById('rno').value="";
		} 
	}

	function Checkcontact(contact)
	{
		var digit=/^[0-9]+$/;
		if(!contact.match(digit))
		{
			alert("Enter Only Digits");
			document.getElementById('contact').value="";
		}	

		if(contact.length>10)
		{

			alert("Enter 10 Digits ");
			document.getElementById('contact').value="";
		}
	}
	</script>
</head>
<body>
<center><fieldset>
	<legend align="center"><h3 style="color:green">Student Information</h3></legend>
	
	<form action="info.php" method="post" name="mform" onsubmit="return validator()">

	<table style="background:grey">
		<tr>
			<td><b>Name:</b></td>
			<td><input type="text" name="name" id="name" autocomplete="off" onkeyup="checkName(this.value)"></td>
		</tr>
		<tr>
			<td><b>Roll No:</b></td>
			<td><input type="text" name="rno" id="rno" autocomplete="off" onkeyup="checkRoll(this.value)"></td>
		</tr>
		<tr>
			<td><b>Contact No:</b></td>
			<td><input type="text" name="contact" id="contact" autocomplete="off" onkeyup="Checkcontact(this.value)">                       </td>
  		</tr>	
		<tr>	<td><input type="submit" value="Submit" name="Submit" style="font-weight:bold"></td>
		</tr>
	</table>

	</form>
</fieldset></center>
</body>
</html>
