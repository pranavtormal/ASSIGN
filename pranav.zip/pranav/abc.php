<?php
	echo "Hello! Welcome to eScan!<br/>";
	echo "Hi<br>";
	echo"the time is".date("h:i:sa")."<br>";
	for($i=1;$i<=5;$i++)
	{
	for($k=1;$k<=5-$i;$k++)
	{
	 echo"&nbsp;";
        }
	 for($j=1;$j<=$i;$j++)
	{
	 echo"*";
	}
	echo"<br>";
	}
	echo"<br>";
	$str="Welcome to escan";
	$str1= explode("o",$str);
	echo implode(" ",$str1);
?>
